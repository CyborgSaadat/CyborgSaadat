package com.scloud.chat;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.gson.Gson;
import com.jgabrielfreitas.core.*;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.io.File;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class ProfileActivity extends AppCompatActivity {
	
	public final int REQ_CD_FP = 101;
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private double get_data_user = 0;
	private boolean edit_prof = false;
	private HashMap<String, Object> put_data = new HashMap<>();
	private HashMap<String, Object> map_intent = new HashMap<>();
	private String data_user_str = "";
	private boolean edit_proff = false;
	private String notifikasi_str = "";
	private String error = "";
	private String fontName = "";
	private String typeace = "";
	
	private ArrayList<HashMap<String, Object>> lm_data_user = new ArrayList<>();
	private ArrayList<String> ls_ = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_notif = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear27;
	private LinearLayout linear1;
	private LinearLayout linear_profile_about;
	private LinearLayout linear11;
	private LinearLayout linear24;
	private Button button2;
	private LinearLayout linear15;
	private LinearLayout linear2;
	private LinearLayout linear6;
	private LinearLayout linear3;
	private LinearLayout linear26;
	private LinearLayout linear4;
	private ImageView imageview_follow;
	private CircleImageView circleimageview1;
	private ImageView imageview11;
	private LinearLayout linear25;
	private TextView textview2;
	private Button button1;
	private TextView textview1;
	private EditText edittext1;
	private TextView textview3;
	private EditText edittext2;
	private TextView textview4;
	private LinearLayout linear23;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private ImageView star;
	private TextView textview16;
	private ImageView imageview4;
	private TextView textview7;
	private ImageView imageview3;
	private TextView textview6;
	private ImageView imageview2;
	private TextView textview5;
	private TextView textview15;
	private LinearLayout linear20;
	private LinearLayout linear19;
	private ImageView imageview10;
	private LinearLayout linear22;
	private TextView textview13;
	private TextView textview11;
	private ImageView imageview9;
	private LinearLayout linear21;
	private TextView textview12;
	private TextView textview10;
	private TextView textview9;
	private LinearLayout linear10;
	private ImageView imageview5;
	private ImageView imageview6;
	private ImageView imageview7;
	private ImageView imageview8;
	private LinearLayout linear_img_upload;
	private ImageView img_u0load;
	
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private Intent fp = new Intent(Intent.ACTION_GET_CONTENT);
	private StorageReference fs = _firebase_storage.getReference("data");
	private OnCompleteListener<Uri> _fs_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _fs_download_success_listener;
	private OnSuccessListener _fs_delete_success_listener;
	private OnProgressListener _fs_upload_progress_listener;
	private OnProgressListener _fs_download_progress_listener;
	private OnFailureListener _fs_failure_listener;
	
	private Intent i = new Intent();
	private AlertDialog.Builder d;
	private DatabaseReference data_user = _firebase.getReference(""+data_user_str+"");
	private ChildEventListener _data_user_child_listener;
	private SharedPreferences share;
	private SharedPreferences kontak;
	private SharedPreferences pesan;
	private DatabaseReference notifikasi = _firebase.getReference(""+notifikasi_str+"");
	private ChildEventListener _notifikasi_child_listener;
	private TimerTask timer;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.profile);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll1 = findViewById(R.id.vscroll1);
		linear27 = findViewById(R.id.linear27);
		linear1 = findViewById(R.id.linear1);
		linear_profile_about = findViewById(R.id.linear_profile_about);
		linear11 = findViewById(R.id.linear11);
		linear24 = findViewById(R.id.linear24);
		button2 = findViewById(R.id.button2);
		linear15 = findViewById(R.id.linear15);
		linear2 = findViewById(R.id.linear2);
		linear6 = findViewById(R.id.linear6);
		linear3 = findViewById(R.id.linear3);
		linear26 = findViewById(R.id.linear26);
		linear4 = findViewById(R.id.linear4);
		imageview_follow = findViewById(R.id.imageview_follow);
		circleimageview1 = findViewById(R.id.circleimageview1);
		imageview11 = findViewById(R.id.imageview11);
		linear25 = findViewById(R.id.linear25);
		textview2 = findViewById(R.id.textview2);
		button1 = findViewById(R.id.button1);
		textview1 = findViewById(R.id.textview1);
		edittext1 = findViewById(R.id.edittext1);
		textview3 = findViewById(R.id.textview3);
		edittext2 = findViewById(R.id.edittext2);
		textview4 = findViewById(R.id.textview4);
		linear23 = findViewById(R.id.linear23);
		linear12 = findViewById(R.id.linear12);
		linear13 = findViewById(R.id.linear13);
		linear14 = findViewById(R.id.linear14);
		star = findViewById(R.id.star);
		textview16 = findViewById(R.id.textview16);
		imageview4 = findViewById(R.id.imageview4);
		textview7 = findViewById(R.id.textview7);
		imageview3 = findViewById(R.id.imageview3);
		textview6 = findViewById(R.id.textview6);
		imageview2 = findViewById(R.id.imageview2);
		textview5 = findViewById(R.id.textview5);
		textview15 = findViewById(R.id.textview15);
		linear20 = findViewById(R.id.linear20);
		linear19 = findViewById(R.id.linear19);
		imageview10 = findViewById(R.id.imageview10);
		linear22 = findViewById(R.id.linear22);
		textview13 = findViewById(R.id.textview13);
		textview11 = findViewById(R.id.textview11);
		imageview9 = findViewById(R.id.imageview9);
		linear21 = findViewById(R.id.linear21);
		textview12 = findViewById(R.id.textview12);
		textview10 = findViewById(R.id.textview10);
		textview9 = findViewById(R.id.textview9);
		linear10 = findViewById(R.id.linear10);
		imageview5 = findViewById(R.id.imageview5);
		imageview6 = findViewById(R.id.imageview6);
		imageview7 = findViewById(R.id.imageview7);
		imageview8 = findViewById(R.id.imageview8);
		linear_img_upload = findViewById(R.id.linear_img_upload);
		img_u0load = findViewById(R.id.img_u0load);
		auth = FirebaseAuth.getInstance();
		fp.setType("image/*");
		fp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		d = new AlertDialog.Builder(this);
		share = getSharedPreferences("share", Activity.MODE_PRIVATE);
		kontak = getSharedPreferences("kontak", Activity.MODE_PRIVATE);
		pesan = getSharedPreferences("pesan", Activity.MODE_PRIVATE);
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.setTitle("SignOut");
				d.setMessage("SignOut will delete your private chat and notification. Continue?");
				d.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						_CoreProgressLoading(true);
						_delete_notifikasi(notifikasi, lm_notif);
						_clearSP(share);
						_clearSP(kontak);
						_clearSP(pesan);
						timer = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										_CoreProgressLoading(false);
										FirebaseAuth.getInstance().signOut();
										finish();
									}
								});
							}
						};
						_timer.schedule(timer, (int)(1700));
					}
				});
				d.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				d.create().show();
			}
		});
		
		imageview_follow.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		circleimageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edit_prof) {
					startActivityForResult(fp, REQ_CD_FP);
				}
			}
		});
		
		textview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", textview2.getText().toString()));
				SketchwareUtil.showMessage(getApplicationContext(), "Email copied");
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (getIntent().getStringExtra("uid").equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (edit_prof) {
						edit_prof = false;
						textview4.setVisibility(View.VISIBLE);
						textview1.setVisibility(View.VISIBLE);
						edittext2.setVisibility(View.GONE);
						edittext1.setVisibility(View.GONE);
						textview4.setText(edittext2.getText().toString());
						button1.setText("Edit");
						put_data.put("about", edittext2.getText().toString());
						data_user.child("data").updateChildren(put_data);
						imageview11.setVisibility(View.INVISIBLE);
						linear26.setVisibility(View.INVISIBLE);
					}
					else {
						edittext2.setVisibility(View.VISIBLE);
						textview4.setVisibility(View.GONE);
						edit_prof = true;
						button1.setText("Save");
						imageview11.setVisibility(View.VISIBLE);
						edittext2.setText(textview4.getText().toString());
						linear26.setVisibility(View.VISIBLE);
					}
				}
				else {
					map_intent = new HashMap<>();
					map_intent.put("uid", getIntent().getStringExtra("uid"));
					map_intent.put("push key", "");
					i.putExtra("data", new Gson().toJson(map_intent));
				}
			}
		});
		
		linear12.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		linear13.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		linear14.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.putExtra("uid", getIntent().getStringExtra("uid"));
				i.setClass(getApplicationContext(), PesanActivity.class);
				startActivity(i);
				finish();
			}
		});
		
		linear20.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		linear19.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		_fs_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				SketchwareUtil.showMessage(getApplicationContext(), "Uploading ".concat(String.valueOf((long)(_progressValue)).concat("%")));
			}
		};
		
		_fs_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fs_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				SketchwareUtil.showMessage(getApplicationContext(), "Upload complete");
				put_data.put("pic url", _downloadUrl);
				data_user.child("data").updateChildren(put_data);
				_curcle_igm_url(_downloadUrl, circleimageview1);
				_CoreProgressLoading(false);
			}
		};
		
		_fs_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_fs_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_fs_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
		
		_data_user_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		data_user.addChildEventListener(_data_user_child_listener);
		
		_notifikasi_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		notifikasi.addChildEventListener(_notifikasi_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
			_changeActivityFont("font");
			linear_img_upload.setVisibility(View.GONE);
			setTitle("Profile");
			linear24.setVisibility(View.INVISIBLE);
			_RoundandShadow(10, 8, "#f44336", button2);
			_RoundandShadow(8, 0, "#eceff1", edittext1);
			_RoundandShadow(8, 0, "#eceff1", edittext2);
			edittext1.setVisibility(View.GONE);
			edit_prof = false;
			edittext2.setVisibility(View.GONE);
			data_user.removeEventListener(_data_user_child_listener);
			data_user_str = "data user/uid/".concat(getIntent().getStringExtra("uid"));
			data_user = _firebase.getReference(data_user_str);
			data_user.addChildEventListener(_data_user_child_listener);
			data_user.addListenerForSingleValueEvent(new ValueEventListener() {
				@Override
				public void onDataChange(DataSnapshot _dataSnapshot) {
					lm_data_user = new ArrayList<>();
					try {
						GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
						for (DataSnapshot _data : _dataSnapshot.getChildren()) {
							HashMap<String, Object> _map = _data.getValue(_ind);
							lm_data_user.add(_map);
						}
					}
					catch (Exception _e) {
						_e.printStackTrace();
					}
					if (lm_data_user.size() > 0) {
						get_data_user = 0;
						textview1.setText(lm_data_user.get((int)get_data_user).get("username").toString());
						textview2.setText(lm_data_user.get((int)get_data_user).get("email").toString());
						edittext1.setText(lm_data_user.get((int)get_data_user).get("username").toString());
						if ("".equals(lm_data_user.get((int)get_data_user).get("pic url").toString())) {
							
						}
						else {
							Glide.with(getApplicationContext()).load(Uri.parse(lm_data_user.get((int)get_data_user).get("pic url").toString())).into(circleimageview1);
						}
						if (lm_data_user.get((int)get_data_user).containsKey("about")) {
							textview4.setText(lm_data_user.get((int)get_data_user).get("about").toString());
							edittext2.setText(lm_data_user.get((int)get_data_user).get("about").toString());
						}
						else {
							textview4.setText(lm_data_user.get((int)get_data_user).get("username").toString());
						}
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "User data not found");
						finish();
					}
				}
				@Override
				public void onCancelled(DatabaseError _databaseError) {
				}
			});
			imageview2.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
			imageview3.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
			imageview4.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
			imageview5.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
			imageview6.setColorFilter(0xFF9E9E9E, PorterDuff.Mode.MULTIPLY);
			imageview7.setColorFilter(0xFFF44336, PorterDuff.Mode.MULTIPLY);
			imageview8.setColorFilter(0xFF00C853, PorterDuff.Mode.MULTIPLY);
			imageview_follow.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
			star.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
			_circleRipple("#cfd8dc", linear12);
			_circleRipple("#cfd8dc", linear13);
			_circleRipple("#cfd8dc", linear14);
			_circleRipple("#cfd8dc", linear23);
			_circleRipple("#cfd8dc", imageview_follow);
			_RoundandShadow(0, 12, "#ffffff", linear_profile_about);
			_RoundandShadow(0, 8, "#ffffff", linear24);
			_RoundandShadow(0, 8, "#ffffff", linear11);
			_RoundandShadow(0, 8, "#ffffff", linear15);
			_RoundandShadow(10, 0, "#607d8b", button1);
			_RoundAndBorder(button1, "#ffffff", 2, "#607d8b", 10);
			_RoundAndBorder(linear19, "#ffffff", 2, "#607d8b", 10);
			_RoundAndBorder(linear20, "#ffffff", 2, "#607d8b", 10);
			_RippleEffect_Round(linear19, "#ffffff", 10);
			_RippleEffect_Round(linear20, "#ffffff", 10);
			if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(getIntent().getStringExtra("uid"))) {
				imageview_follow.setVisibility(View.GONE);
				button2.setVisibility(View.VISIBLE);
				linear14.setAlpha((float)(0.6d));
				linear14.setEnabled(false);
				textview6.setText("My project");
			}
			else {
				_RoundAndBorder(button1, "#ffffff", 4, "#f44336", 10);
				button1.setText("report");
				button1.setTextColor(0xFFF44336);
				button2.setVisibility(View.GONE);
			}
			imageview_follow.setVisibility(View.GONE);
			linear23.setVisibility(View.GONE);
		}
		else {
			finish();
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FP:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				try {
					_CoreProgressLoading(true);
					FileUtil.resizeBitmapFileRetainRatio(_filePath.get((int)(0)), FileUtil.getPackageDataDir(getApplicationContext()).concat("/pic_temp/pic.png"), 300);
					img_u0load.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(FileUtil.getPackageDataDir(getApplicationContext()).concat("/pic_temp/pic.png"), 1024, 1024));
					fs.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("/pic/".concat("pic.png"))).putFile(Uri.fromFile(new File(FileUtil.getPackageDataDir(getApplicationContext()).concat("/pic_temp/pic.png")))).addOnFailureListener(_fs_failure_listener).addOnProgressListener(_fs_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
						@Override
						public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
							return fs.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("/pic/".concat("pic.png"))).getDownloadUrl();
						}}).addOnCompleteListener(_fs_upload_success_listener);
				}
				
				catch (Exception e)
				{
					error = e.toString();
					SketchwareUtil.showMessage(getApplicationContext(), "Pick another image in your local storage");
				}
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	public void _circleRipple(final String _color, final View _v) {
		android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor(_color)});
		android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , null, null);
		_v.setBackground(ripdrb);
	}
	
	
	public void _RoundAndBorder(final View _view, final String _color1, final double _border, final String _color2, final double _round) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color1));
		gd.setCornerRadius((int) _round);
		gd.setStroke((int) _border, Color.parseColor(_color2));
		_view.setBackground(gd);
	}
	
	
	public void _RoundandShadow(final double _Radius, final double _Elevation, final String _color, final View _v) {
		float r = (float) _Radius;
		float e = (float) _Elevation;
		_v.setElevation(e);
		android.graphics.drawable.GradientDrawable s=new android.graphics.drawable.GradientDrawable();
		s.setColor(Color.parseColor(_color));
		s.setCornerRadius(r);
		_v.setBackground(s);
	}
	
	
	public void _RippleEffect_Round(final View _view, final String _color, final double _clr) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(Color.parseColor(_color));
		GG.setCornerRadius((float)_clr);
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor("#FF757575")}), GG, null);
		_view.setBackground(RE);
	}
	
	
	public void _roundImageViewUrl(final ImageView _imageview, final double _round, final String _url) {
		_curcle_igm_url(_url, _imageview);
	}
	
	
	public void _curcle_igm_url(final String _url, final ImageView _img_view) {
		
	}
	
	
	public void _get_user_info() {
		_RoundandShadow(10, 8, "#f44336", button2);
		_RoundandShadow(8, 0, "#eceff1", edittext1);
		_RoundandShadow(8, 0, "#eceff1", edittext2);
		edittext1.setVisibility(View.GONE);
		edit_prof = false;
		edittext2.setVisibility(View.GONE);
		imageview2.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
		imageview3.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
		imageview4.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
		imageview5.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		imageview6.setColorFilter(0xFF9E9E9E, PorterDuff.Mode.MULTIPLY);
		imageview7.setColorFilter(0xFFF44336, PorterDuff.Mode.MULTIPLY);
		imageview8.setColorFilter(0xFF00C853, PorterDuff.Mode.MULTIPLY);
		imageview_follow.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
		star.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
		_circleRipple("#cfd8dc", linear12);
		_circleRipple("#cfd8dc", linear13);
		_circleRipple("#cfd8dc", linear14);
		_circleRipple("#cfd8dc", linear23);
		_circleRipple("#cfd8dc", imageview_follow);
		_RoundandShadow(0, 12, "#ffffff", linear_profile_about);
		_RoundandShadow(0, 8, "#ffffff", linear24);
		_RoundandShadow(0, 8, "#ffffff", linear11);
		_RoundandShadow(0, 8, "#ffffff", linear15);
		_RoundandShadow(10, 0, "#607d8b", button1);
		_RoundAndBorder(button1, "#ffffff", 2, "#607d8b", 10);
		_RoundAndBorder(linear19, "#ffffff", 2, "#607d8b", 10);
		_RoundAndBorder(linear20, "#ffffff", 2, "#607d8b", 10);
		_RippleEffect_Round(linear19, "#ffffff", 10);
		_RippleEffect_Round(linear20, "#ffffff", 10);
		if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(getIntent().getStringExtra("uid"))) {
			imageview_follow.setVisibility(View.GONE);
			button2.setVisibility(View.VISIBLE);
		}
		else {
			_RoundAndBorder(button1, "#ffffff", 4, "#f44336", 10);
			button1.setText("report");
			button1.setTextColor(0xFFF44336);
			button2.setVisibility(View.GONE);
		}
		imageview_follow.setVisibility(View.GONE);
		linear23.setVisibility(View.GONE);
	}
	
	
	public void _saveView(final String _path, final String _filename, final View _view) {
		FileUtil.writeFile(_path, _filename);
		Bitmap returnedBitmap = Bitmap.createBitmap(_view.getWidth(), _view.getHeight(),Bitmap.Config.ARGB_8888);
		
		Canvas canvas = new Canvas(returnedBitmap);
		
		android.graphics.drawable.Drawable bgDrawable =_view.getBackground();
		
		if (bgDrawable!=null) {
			bgDrawable.draw(canvas);
			
		} else {
			
			canvas.drawColor(Color.WHITE);
		}
		_view.draw(canvas);
		
		java.io.File pictureFile = new java.io.File(Environment.getExternalStorageDirectory() + _path + _filename);
		
		if (pictureFile == null) {
			showMessage("Error creating media file, check storage permissions: ");
			
			return; }
		
		try {
			java.io.FileOutputStream fos = new java.io.FileOutputStream(pictureFile);
			 returnedBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
			fos.close();
			
			showMessage("Image Saved in" + _path);
			
		} catch (java.io.FileNotFoundException e) {
			showMessage("File not found: " + e.getMessage()); 
			
		} catch 
		(java.io.IOException e) {
			showMessage("Error accessing file: " + e.getMessage());
		};
	}
	
	
	public void _CoreProgressLoading(final boolean _ifShow) {
		if (_ifShow) {
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.setMessage(null);
			coreprog.show();
			coreprog.setContentView(R.layout.custom_dialog);
		}
		else {
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	public void _clearSP(final SharedPreferences _sharedPreference) {
		_sharedPreference.edit().clear().commit();
	}
	
	
	public void _delete_notifikasi(final DatabaseReference _fdb, final ArrayList<HashMap<String, Object>> _list_map) {
		notifikasi.removeEventListener(_notifikasi_child_listener);
		notifikasi_str = "notifikasi/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid());
		notifikasi = _firebase.getReference(notifikasi_str);
		notifikasi.addChildEventListener(_notifikasi_child_listener);
		notifikasi.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				lm_notif = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						lm_notif.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				if (lm_notif.size() == 0) {
					
				}
				else {
					get_data_user = 0;
					for(int _repeat32 = 0; _repeat32 < (int)(lm_notif.size()); _repeat32++) {
						if ("dibuka".equals(lm_notif.get((int)get_data_user).get("status").toString()) || "read".equals(lm_notif.get((int)get_data_user).get("status").toString())) {
							notifikasi.child(lm_notif.get((int)get_data_user).get("push key").toString()).removeValue();
						}
						get_data_user++;
					}
				}
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
	}
	
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		int style = 0;
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					
					if (((TextView) v).getTypeface().getStyle()==Typeface.NORMAL) {
						
						style = 0;
						
					}else{
						
						if (((TextView) v).getTypeface().getStyle()==Typeface.BOLD) {
							
							style = 1;
							
						}else{
							
							if (((TextView) v).getTypeface().getStyle()==Typeface.ITALIC) {
								
								style = 2;
								
							}else{
								
								if (((TextView) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
									
									style = 3;
									
								}}}}
					
					((TextView) v).setTypeface(typeace, (style));
					
				}
				else {
					if ((v instanceof EditText )) {
						if (((EditText) v).getTypeface().getStyle()==Typeface.NORMAL) {
							
							style = 0;
							
						}else{
							
							if (((EditText) v).getTypeface().getStyle()==Typeface.BOLD) {
								
								style = 1;
								
							}else{
								
								if (((EditText) v).getTypeface().getStyle()==Typeface.ITALIC) {
									
									style = 2;
									
								}else{
									
									if (((EditText) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
										
										style = 3;
										
									}}}}
						
						((EditText) v).setTypeface(typeace, (style));
					}
					else {
						if ((v instanceof RadioButton )) {
							if (((RadioButton) v).getTypeface().getStyle()==Typeface.NORMAL) {
								
								style = 0;
								
							}else{
								
								if (((RadioButton) v).getTypeface().getStyle()==Typeface.BOLD) {
									
									style = 1;
									
								}else{
									
									if (((RadioButton) v).getTypeface().getStyle()==Typeface.ITALIC) {
										
										style = 2;
										
									}else{
										
										if (((RadioButton) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
											
											style = 3;
											
										}}}}
							
							((RadioButton) v).setTypeface(typeace, (style));
						}
						else {
							if ((v instanceof CheckBox )) {
								if (((CheckBox) v).getTypeface().getStyle()==Typeface.NORMAL) {
									
									style = 0;
									
								}else{
									
									if (((CheckBox) v).getTypeface().getStyle()==Typeface.BOLD) {
										
										style = 1;
										
									}else{
										
										if (((CheckBox) v).getTypeface().getStyle()==Typeface.ITALIC) {
											
											style = 2;
											
										}else{
											
											if (((CheckBox) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
												
												style = 3;
												
											}}}}
								
								((CheckBox) v).setTypeface(typeace, (style));
							}
							else {
								if ((v instanceof Switch )) {
									if (((Switch) v).getTypeface().getStyle()==Typeface.NORMAL) {
										
										style = 0;
										
									}else{
										
										if (((Switch) v).getTypeface().getStyle()==Typeface.BOLD) {
											
											style = 1;
											
										}else{
											
											if (((Switch) v).getTypeface().getStyle()==Typeface.ITALIC) {
												
												style = 2;
												
											}else{
												
												if (((Switch) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
													
													style = 3;
													
												}}}}
									
									((Switch) v).setTypeface(typeace, (style));
								}
								else {
									if ((v instanceof Button)) {
										if (((Button) v).getTypeface().getStyle()==Typeface.NORMAL) {
											
											style = 0;
											
										}else{
											
											if (((Button) v).getTypeface().getStyle()==Typeface.BOLD) {
												
												style = 1;
												
											}else{
												
												if (((Button) v).getTypeface().getStyle()==Typeface.ITALIC) {
													
													style = 2;
													
												}else{
													
													if (((Button) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
														
														style = 3;
														
													}}}}
										
										((Button) v).setTypeface(typeace, (style));
									}
								}
							}
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}