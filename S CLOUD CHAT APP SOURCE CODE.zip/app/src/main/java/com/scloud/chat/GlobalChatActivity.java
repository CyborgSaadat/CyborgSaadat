package com.scloud.chat;

import android.Manifest;
import android.animation.*;
import android.animation.ObjectAnimator;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.media.SoundPool;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.jgabrielfreitas.core.*;
import java.io.*;
import java.io.File;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import com.jgabrielfreitas.core.BlurImageView;

public class GlobalChatActivity extends AppCompatActivity {
	
	public final int REQ_CD_FP_IMG = 101;
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private double besar = 0;
	private double kecil = 0;
	private String warna_uid1 = "";
	private String warna_uid_2 = "";
	private double get_username = 0;
	private HashMap<String, Object> map_pesan = new HashMap<>();
	private String push_key = "";
	private String error = "";
	private String pesan_ = "";
	private HashMap<String, Object> map_warna = new HashMap<>();
	private double sedang = 0;
	private HashMap<String, Object> map_typing = new HashMap<>();
	private String sebelum = "";
	private boolean mengetik = false;
	private String set_subtittle = "";
	private HashMap<String, Object> map_users_in_gchat = new HashMap<>();
	private String put_warna_sya = "";
	private HashMap<String, Object> put_my_color = new HashMap<>();
	private String data_user_str = "";
	private double get_data_user_ = 0;
	private HashMap<String, Object> map_dataUser_Temp = new HashMap<>();
	private double sound_sent = 0;
	private double sound_receive = 0;
	private boolean onChildAdded = false;
	private boolean sound = false;
	private double panjang_pesan = 0;
	private double panjang_jam = 0;
	private String pesan_jam = "";
	private String set_Subtittle = "";
	private boolean scroll = false;
	private String item_ = "";
	private double wh_ = 0;
	private String uid = "";
	private String timstaps_str = "";
	private String usernamee = "";
	private HashMap<String, Object> map_stiker = new HashMap<>();
	private String stiker_str = "";
	private HashMap<String, Object> map_sticker_downloaded = new HashMap<>();
	private double cek_stiker = 0;
	private String key_sticker = "";
	private String id_stiker_buat_d = "";
	private HashMap<String, Object> map_stiker_key_temp = new HashMap<>();
	private HashMap<String, Object> map_stiker_dl_temp = new HashMap<>();
	private boolean hidden = false;
	private String ekspresi = "";
	private double cari_stiker = 0;
	private HashMap<String, Object> mapdled = new HashMap<>();
	private String fontName = "";
	private String typeace = "";
	private String typing_str = "";
	private String typing_str2 = "";
	private String img = "";
	private String pesanUploadGambar = "";
	private boolean uploadingImg = false;
	private HashMap<String, Object> push_data_blocked = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> lm_data_user = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_chat = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_pesan = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_warna = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_typing = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_user_in_gchat = new ArrayList<>();
	private ArrayList<String> ls_warna = new ArrayList<>();
	private ArrayList<String> ls_users = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_dataUser_temp = new ArrayList<>();
	private ArrayList<String> ls_dialog_ = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> map_kontak_temp = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_stiker = new ArrayList<>();
	private ArrayList<String> ls_stiker_url_dl = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_stiker_db_temp = new ArrayList<>();
	private ArrayList<String> ls_cek_downloaded_sticker = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_stiker_key_temp = new ArrayList<>();
	private ArrayList<String> ls_stiker_key_temp = new ArrayList<>();
	private ArrayList<String> ls_stiker_key = new ArrayList<>();
	private ArrayList<String> ls_stiker_file = new ArrayList<>();
	
	private LinearLayout linear1;
	private ListView listview1;
	private LinearLayout linear3;
	private LinearLayout linear2;
	private LinearLayout linear4;
	private GridView gridview_sticker;
	private FrameLayout linear5;
	private ImageView imageview1;
	private EditText edittext2;
	private Button button2;
	private ImageView imageview9;
	private ImageView imageview10;
	private ProgressBar progressbar1;
	private ImageView imageview2;
	private ImageView imageview3;
	private ImageView imageview4;
	
	private SharedPreferences share;
	private DatabaseReference global_chat = _firebase.getReference("chat global/chat");
	private ChildEventListener _global_chat_child_listener;
	private Calendar c = Calendar.getInstance();
	private ObjectAnimator anim = new ObjectAnimator();
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference warna = _firebase.getReference("chat global/warna");
	private ChildEventListener _warna_child_listener;
	private SharedPreferences kontak;
	private DatabaseReference chat_global = _firebase.getReference("chat global/typing/");
	private ChildEventListener _chat_global_child_listener;
	private TimerTask mengetik_;
	private DatabaseReference latest_message = _firebase.getReference("chat global/pesan terbaru/");
	private ChildEventListener _latest_message_child_listener;
	private DatabaseReference user_in_gchat = _firebase.getReference("chat global/users/");
	private ChildEventListener _user_in_gchat_child_listener;
	private DatabaseReference data_user = _firebase.getReference(""+data_user_str+"");
	private ChildEventListener _data_user_child_listener;
	private SoundPool sound_pool;
	private TimerTask u;
	private AlertDialog.Builder ls_dialog;
	private Intent i = new Intent();
	private Calendar time_stamp = Calendar.getInstance();
	private Calendar timestamp_1 = Calendar.getInstance();
	private Calendar cale__1 = Calendar.getInstance();
	private Calendar ts = Calendar.getInstance();
	private Calendar get_typing_ = Calendar.getInstance();
	private DatabaseReference stiker = _firebase.getReference(""+stiker_str+"");
	private ChildEventListener _stiker_child_listener;
	private StorageReference stiker_fs = _firebase_storage.getReference("stiker");
	private OnCompleteListener<Uri> _stiker_fs_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _stiker_fs_download_success_listener;
	private OnSuccessListener _stiker_fs_delete_success_listener;
	private OnProgressListener _stiker_fs_upload_progress_listener;
	private OnProgressListener _stiker_fs_download_progress_listener;
	private OnFailureListener _stiker_fs_failure_listener;
	
	private AlertDialog.Builder dialog2;
	private DatabaseReference sticker_key_ = _firebase.getReference("stiker key");
	private ChildEventListener _sticker_key__child_listener;
	private TimerTask timer_typing;
	private Intent fp_img = new Intent(Intent.ACTION_GET_CONTENT);
	private StorageReference global_img = _firebase_storage.getReference("global img img");
	private OnCompleteListener<Uri> _global_img_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _global_img_download_success_listener;
	private OnSuccessListener _global_img_delete_success_listener;
	private OnProgressListener _global_img_upload_progress_listener;
	private OnProgressListener _global_img_download_progress_listener;
	private OnFailureListener _global_img_failure_listener;
	
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.global_chat);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = findViewById(R.id.linear1);
		listview1 = findViewById(R.id.listview1);
		linear3 = findViewById(R.id.linear3);
		linear2 = findViewById(R.id.linear2);
		linear4 = findViewById(R.id.linear4);
		gridview_sticker = findViewById(R.id.gridview_sticker);
		linear5 = findViewById(R.id.linear5);
		imageview1 = findViewById(R.id.imageview1);
		edittext2 = findViewById(R.id.edittext2);
		button2 = findViewById(R.id.button2);
		imageview9 = findViewById(R.id.imageview9);
		imageview10 = findViewById(R.id.imageview10);
		progressbar1 = findViewById(R.id.progressbar1);
		imageview2 = findViewById(R.id.imageview2);
		imageview3 = findViewById(R.id.imageview3);
		imageview4 = findViewById(R.id.imageview4);
		share = getSharedPreferences("share", Activity.MODE_PRIVATE);
		auth = FirebaseAuth.getInstance();
		kontak = getSharedPreferences("kontak", Activity.MODE_PRIVATE);
		ls_dialog = new AlertDialog.Builder(this);
		dialog2 = new AlertDialog.Builder(this);
		fp_img.setType("image/*");
		fp_img.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		
		listview1.setOnScrollListener(new AbsListView.OnScrollListener() {
			@Override
			public void onScrollStateChanged(AbsListView abs, int _scrollState) {
				
			}
			
			@Override
			public void onScroll(AbsListView abs, int _firstVisibleItem, int _visibleItemCount, int _totalItemCount) {
				
			}
		});
		
		listview1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				
				return true;
			}
		});
		
		gridview_sticker.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				scroll = true;
				map_pesan.clear();
				c = Calendar.getInstance();
				push_key = global_chat.push().getKey();
				map_pesan = new HashMap<>();
				map_pesan.put("pesan", "");
				map_pesan.put("tanggal", new SimpleDateFormat("MMM dd, yyyy").format(c.getTime()));
				map_pesan.put("jam", new SimpleDateFormat("HH:mm").format(c.getTime()));
				map_pesan.put("gmt", new SimpleDateFormat("ZZZZ").format(c.getTime()));
				map_pesan.put("reply", "");
				map_pesan.put("reply id", "");
				map_pesan.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				map_pesan.put("username", share.getString("username", ""));
				map_pesan.put("id stiker", Uri.parse(lm_stiker.get((int)_position).get("stiker").toString()).getLastPathSegment());
				map_pesan.put("push key", push_key);
				map_pesan.put("time stamp", String.valueOf((long)(c.getTimeInMillis())));
				map_pesan.put("ukuran stiker", "");
				global_chat.child(push_key).updateChildren(map_pesan);
				latest_message.child("ims terbaru").updateChildren(map_pesan);
				edittext2.setText("");
				button2.setAlpha((float)(0.5d));
				button2.setText("send");
				map_pesan.clear();
			}
		});
		
		gridview_sticker.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				ls_dialog.setMessage("Delete selected sticker?");
				ls_dialog.setPositiveButton("yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						lm_stiker.remove((int)(_position));
						share.edit().putString("stiker", new Gson().toJson(lm_stiker)).commit();
						gridview_sticker.setAdapter(new Gridview_stickerAdapter(lm_stiker));
						gridview_sticker.setNumColumns((int)3);
						gridview_sticker.setColumnWidth((int)SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 3);
						gridview_sticker.setVerticalSpacing((int)5);
						gridview_sticker.setHorizontalSpacing((int)5);
						gridview_sticker.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
					}
				});
				ls_dialog.create().show();
				return true;
			}
		});
		
		imageview1.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				i.setClass(getApplicationContext(), UploadStickerActivity.class);
				startActivity(i);
				return true;
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (hidden) {
					_scan_sticker();
					edittext2.setVisibility(View.VISIBLE);
					linear4.setVisibility(View.VISIBLE);
					gridview_sticker.setVisibility(View.VISIBLE);
					hidden = false;
					_LayoutParams_Height(gridview_sticker, SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) / 3);
					SketchwareUtil.hideKeyboard(getApplicationContext());
				}
				else {
					edittext2.setEnabled(true);
					linear4.setVisibility(View.GONE);
					edittext2.setVisibility(View.VISIBLE);
					gridview_sticker.setVisibility(View.GONE);
					hidden = true;
					SketchwareUtil.showKeyboard(getApplicationContext());
				}
			}
		});
		
		edittext2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				gridview_sticker.setVisibility(View.GONE);
				linear4.setVisibility(View.GONE);
				hidden = true;
			}
		});
		
		edittext2.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (uploadingImg) {
					button2.setEnabled(false);
				}
				else {
					if ((_charSeq.trim().length() < 1) || (_charSeq.trim().length() > 2500)) {
						anim.setTarget(button2);
						anim.setPropertyName("alpha");
						anim.setFloatValues((float)(0.5d));
						anim.setDuration((int)(100));
						anim.setRepeatMode(ValueAnimator.RESTART);
						anim.setRepeatCount((int)(0));
						anim.setInterpolator(new LinearInterpolator());
						anim.start();
						button2.setEnabled(false);
					}
					else {
						if (_charSeq.trim().length() > 0) {
							button2.setEnabled(true);
							anim.setTarget(button2);
							anim.setPropertyName("alpha");
							anim.setFloatValues((float)(1));
							anim.setDuration((int)(100));
							anim.setRepeatMode(ValueAnimator.RESTART);
							anim.setRepeatCount((int)(0));
							anim.setInterpolator(new LinearInterpolator());
							anim.start();
							if (img.equals("")) {
								c = Calendar.getInstance();
								map_typing.put("username", share.getString("username", ""));
								map_typing.put("typing", String.valueOf((long)(c.getTimeInMillis())));
								chat_global.child("global typing").updateChildren(map_typing);
							}
							else {
								
							}
						}
					}
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button2.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				
				return true;
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext2.getText().toString().equals("")) {
					
				}
				else {
					if (img.equals("")) {
						pesan_ = edittext2.getText().toString().trim().replace("\n\n", "\n");
					}
					else {
						if (uploadingImg) {
							pesan_ = edittext2.getText().toString().trim().replace("\n\n", "\n");
						}
						else {
							pesanUploadGambar = edittext2.getText().toString().trim().replace("\n\n", "\n");
						}
					}
				}
				push_key = global_chat.push().getKey();
				if (uploadingImg) {
					scroll = true;
					c = Calendar.getInstance();
					map_pesan = new HashMap<>();
					map_pesan.put("pesan", pesan_);
					map_pesan.put("tanggal", new SimpleDateFormat("MMM dd, yyyy").format(c.getTime()));
					map_pesan.put("jam", new SimpleDateFormat("HH:mm").format(c.getTime()));
					map_pesan.put("gmt", new SimpleDateFormat("ZZZZ").format(c.getTime()));
					map_pesan.put("reply", "");
					map_pesan.put("reply id", "");
					map_pesan.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
					map_pesan.put("username", share.getString("username", ""));
					map_pesan.put("id stiker", "");
					map_pesan.put("push key", push_key);
					map_pesan.put("time stamp", String.valueOf((long)(c.getTimeInMillis())));
					global_chat.child(push_key).updateChildren(map_pesan);
					latest_message.child("ims terbaru").updateChildren(map_pesan);
					edittext2.setText("");
					button2.setAlpha((float)(0.5d));
					button2.setText("send");
				}
				else {
					if (img.equals("")) {
						scroll = true;
						c = Calendar.getInstance();
						map_pesan = new HashMap<>();
						map_pesan.put("pesan", pesan_);
						map_pesan.put("tanggal", new SimpleDateFormat("MMM dd, yyyy").format(c.getTime()));
						map_pesan.put("jam", new SimpleDateFormat("HH:mm").format(c.getTime()));
						map_pesan.put("gmt", new SimpleDateFormat("ZZZZ").format(c.getTime()));
						map_pesan.put("reply", "");
						map_pesan.put("reply id", "");
						map_pesan.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
						map_pesan.put("username", share.getString("username", ""));
						map_pesan.put("id stiker", "");
						map_pesan.put("push key", push_key);
						map_pesan.put("time stamp", String.valueOf((long)(c.getTimeInMillis())));
						global_chat.child(push_key).updateChildren(map_pesan);
						latest_message.child("ims terbaru").updateChildren(map_pesan);
						edittext2.setText("");
						button2.setAlpha((float)(0.5d));
						button2.setText("send");
					}
					else {
						if (FileUtil.isExistFile(img)) {
							uploadingImg = true;
							c = Calendar.getInstance();
							global_img.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("/".concat(String.valueOf((long)(c.getTimeInMillis()))))).putFile(Uri.fromFile(new File(img))).addOnFailureListener(_global_img_failure_listener).addOnProgressListener(_global_img_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
								@Override
								public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
									return global_img.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("/".concat(String.valueOf((long)(c.getTimeInMillis()))))).getDownloadUrl();
								}}).addOnCompleteListener(_global_img_upload_success_listener);
							button2.setText("send");
							imageview9.setVisibility(View.VISIBLE);
							button2.setAlpha((float)(0.5d));
						}
						else {
							SketchwareUtil.showMessage(getApplicationContext(), "file tidak ditemukan ");
							linear4.setVisibility(View.GONE);
							
							gridview_sticker.setVisibility(View.GONE);
							edittext2.setEnabled(false);
							button2.setEnabled(false);
						}
					}
				}
			}
		});
		
		imageview9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (uploadingImg) {
					SketchwareUtil.showMessage(getApplicationContext(), "Upload on progress");
				}
				else {
					startActivityForResult(fp_img, REQ_CD_FP_IMG);
				}
			}
		});
		
		imageview10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (uploadingImg) {
					SketchwareUtil.showMessage(getApplicationContext(), "Upload on progress");
				}
				else {
					if (hidden) {
						_scan_sticker();
						edittext2.setVisibility(View.VISIBLE);
						edittext2.setEnabled(false);
						linear4.setVisibility(View.VISIBLE);
						gridview_sticker.setVisibility(View.VISIBLE);
						hidden = false;
						_LayoutParams_Height(gridview_sticker, SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) / 3);
					}
					else {
						edittext2.setEnabled(true);
						linear4.setVisibility(View.GONE);
						edittext2.setVisibility(View.VISIBLE);
						gridview_sticker.setVisibility(View.GONE);
						hidden = true;
						img = "";
						linear5.setVisibility(View.GONE);
						imageview1.setVisibility(View.VISIBLE);
					}
				}
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				gridview_sticker.setVisibility(View.VISIBLE);
				imageview9.setVisibility(View.GONE);
				img = "";
				_scan_sticker();
				edittext2.setVisibility(View.VISIBLE);
				edittext2.setEnabled(false);
				gridview_sticker.setVisibility(View.VISIBLE);
				gridview_sticker.setVisibility(View.VISIBLE);
				hidden = false;
				_LayoutParams_Height(gridview_sticker, SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) / 3);
				_LayoutParams_Height(imageview9, SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) / 3);
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(fp_img, REQ_CD_FP_IMG);
			}
		});
		
		_global_chat_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (onChildAdded) {
					global_chat.addListenerForSingleValueEvent(new ValueEventListener() {
						@Override
						public void onDataChange(DataSnapshot _dataSnapshot) {
							lm_pesan = new ArrayList<>();
							try {
								GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
								for (DataSnapshot _data : _dataSnapshot.getChildren()) {
									HashMap<String, Object> _map = _data.getValue(_ind);
									lm_pesan.add(_map);
								}
							}
							catch (Exception _e) {
								_e.printStackTrace();
							}
							if (scroll) {
								int _index =listview1.getFirstVisiblePosition();
								View _view = listview1.getChildAt(0);
								int _top = (_view == null) ? 0 : _view.getTop();
								listview1.setAdapter(new Listview1Adapter(lm_pesan));
								((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
								listview1.setSelectionFromTop(_index,_top);
								scroll = false;
								listview1.smoothScrollToPosition((int)(lm_pesan.size() - 1));
							}
							else {
								int _index =listview1.getFirstVisiblePosition();
								View _view = listview1.getChildAt(0);
								int _top = (_view == null) ? 0 : _view.getTop();
								listview1.setAdapter(new Listview1Adapter(lm_pesan));
								((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
								listview1.setSelectionFromTop(_index,_top);
								listview1.smoothScrollToPosition((int)(lm_pesan.size() - 1));
							}
							if (sound) {
								if (lm_pesan.get((int)lm_pesan.size() - 1).get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
									sound_sent = sound_pool.play((int)(1), 1.0f, 1.0f, 1, (int)(0), 1.0f);
								}
								else {
									sound_receive = sound_pool.play((int)(2), 1.0f, 1.0f, 1, (int)(0), 1.0f);
								}
							}
						}
						@Override
						public void onCancelled(DatabaseError _databaseError) {
						}
					});
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (onChildAdded) {
					global_chat.addListenerForSingleValueEvent(new ValueEventListener() {
						@Override
						public void onDataChange(DataSnapshot _dataSnapshot) {
							lm_pesan = new ArrayList<>();
							try {
								GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
								for (DataSnapshot _data : _dataSnapshot.getChildren()) {
									HashMap<String, Object> _map = _data.getValue(_ind);
									lm_pesan.add(_map);
								}
							}
							catch (Exception _e) {
								_e.printStackTrace();
							}
							int _index =listview1.getFirstVisiblePosition();
							View _view = listview1.getChildAt(0);
							int _top = (_view == null) ? 0 : _view.getTop();
							listview1.setAdapter(new Listview1Adapter(lm_pesan));
							((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
							listview1.setSelectionFromTop(_index,_top);
						}
						@Override
						public void onCancelled(DatabaseError _databaseError) {
						}
					});
				}
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				SketchwareUtil.showMessage(getApplicationContext(), "You've been blocked from global chat");
			}
		};
		global_chat.addChildEventListener(_global_chat_child_listener);
		
		_warna_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		warna.addChildEventListener(_warna_child_listener);
		
		_chat_global_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				usernamee = _childValue.get("username").toString();
				typing_str = _childValue.get("typing").toString();
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		chat_global.addChildEventListener(_chat_global_child_listener);
		
		_latest_message_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		latest_message.addChildEventListener(_latest_message_child_listener);
		
		_user_in_gchat_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				user_in_gchat.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						lm_user_in_gchat = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								lm_user_in_gchat.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						if (lm_user_in_gchat.size() > 0) {
							map_users_in_gchat = lm_user_in_gchat.get((int)0);
							SketchwareUtil.getAllKeysFromMap(map_users_in_gchat, ls_users);
							_get_users();
							share.edit().putString("users in gchat", new Gson().toJson(map_users_in_gchat)).commit();
							if (map_users_in_gchat.containsKey(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
								
							}
							else {
								_atur_warna_saya();
							}
						}
						else {
							_atur_warna_saya();
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				user_in_gchat.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						lm_user_in_gchat = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								lm_user_in_gchat.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						if (lm_user_in_gchat.size() > 0) {
							try{
								map_users_in_gchat = lm_user_in_gchat.get((int)0);
								SketchwareUtil.getAllKeysFromMap(map_users_in_gchat, ls_users);
								_get_users();
								share.edit().putString("users in gchat", new Gson().toJson(map_users_in_gchat)).commit();
								if (map_users_in_gchat.containsKey(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
									
								}
								else {
									_atur_warna_saya();
								}
							}catch(Exception e){
								 
							}
						}
						else {
							_atur_warna_saya();
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
				SketchwareUtil.showMessage(getApplicationContext(), "Gagal update 1");
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		user_in_gchat.addChildEventListener(_user_in_gchat_child_listener);
		
		_data_user_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		data_user.addChildEventListener(_data_user_child_listener);
		
		_stiker_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		stiker.addChildEventListener(_stiker_child_listener);
		
		_stiker_fs_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_stiker_fs_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_stiker_fs_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				
			}
		};
		
		_stiker_fs_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				try{
					if (FileUtil.isExistFile(FileUtil.getPackageDataDir(getApplicationContext()).concat("/sticker/".concat(ls_stiker_key_temp.get((int)(cek_stiker)).concat("_temp"))))) {
						FileUtil.moveFile(FileUtil.getPackageDataDir(getApplicationContext()).concat("/sticker/".concat(ls_stiker_key_temp.get((int)(cek_stiker)).concat("_temp"))), FileUtil.getPackageDataDir(getApplicationContext()).concat("/sticker/".concat(ls_stiker_key_temp.get((int)(cek_stiker)))));
						map_sticker_downloaded.put(ls_stiker_key_temp.get((int)(cek_stiker)), "true");
						share.edit().putString("map stiker key", new Gson().toJson(map_sticker_downloaded)).commit();
						map_sticker_downloaded.put(ls_stiker_key_temp.get((int)(cek_stiker)), "true");
						share.edit().putString("key sticker", new Gson().toJson(map_sticker_downloaded)).commit();
						int _index =listview1.getFirstVisiblePosition();
						View _view = listview1.getChildAt(0);
						int _top = (_view == null) ? 0 : _view.getTop();
						listview1.setAdapter(new Listview1Adapter(lm_pesan));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
						listview1.setSelectionFromTop(_index,_top);
						cek_stiker++;
						_mulai_unduh_stiker();
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), Uri.parse(FileUtil.getPackageDataDir(getApplicationContext()).concat("/sticker/".concat(ls_stiker_key_temp.get((int)(cek_stiker)).concat("_temp")))).getLastPathSegment().concat(" tidak tersedia"));
					}
				}catch(Exception e){
					_mulai_unduh_stiker();
				}
			}
		};
		
		_stiker_fs_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_stiker_fs_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
		
		_sticker_key__child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		sticker_key_.addChildEventListener(_sticker_key__child_listener);
		
		_global_img_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				imageview1.setVisibility(View.GONE);
				progressbar1.setVisibility(View.VISIBLE);
				button2.setEnabled(false);
			}
		};
		
		_global_img_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_global_img_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				try{
					push_key = global_chat.push().getKey();
					c = Calendar.getInstance();
					map_pesan = new HashMap<>();
					map_pesan.put("pesan", pesanUploadGambar);
					map_pesan.put("tanggal", new SimpleDateFormat("MMM dd, yyyy").format(c.getTime()));
					map_pesan.put("jam", new SimpleDateFormat("HH:mm").format(c.getTime()));
					map_pesan.put("gmt", new SimpleDateFormat("ZZZZ").format(c.getTime()));
					map_pesan.put("reply", "");
					map_pesan.put("reply id", "");
					map_pesan.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
					map_pesan.put("username", share.getString("username", ""));
					map_pesan.put("gambar", _downloadUrl);
					map_pesan.put("id stiker", "");
					map_pesan.put("push key", push_key);
					map_pesan.put("time stamp", String.valueOf((long)(c.getTimeInMillis())));
					global_chat.child(push_key).updateChildren(map_pesan);
					latest_message.child("ims terbaru").updateChildren(map_pesan);
					progressbar1.setVisibility(View.GONE);
					imageview1.setVisibility(View.VISIBLE);
					SketchwareUtil.showMessage(getApplicationContext(), "Image uploaded");
					pesanUploadGambar = "";
					img = "";
					map_pesan.clear();
					uploadingImg = false;
					linear5.setVisibility(View.GONE);
					edittext2.setText("");
					edittext2.setEnabled(true);
				}catch(Exception e){
					SketchwareUtil.showMessage(getApplicationContext(), e.toString());
				}
			}
		};
		
		_global_img_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_global_img_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_global_img_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		setTitle("Global chat");
		progressbar1.setVisibility(View.GONE);
		linear5.setVisibility(View.GONE);
		_changeActivityFont("font");
		_CoreProgressLoading(true);
		imageview9.setVisibility(View.GONE);
		gridview_sticker.setVisibility(View.GONE);
		hidden = true;
		_stiker_tool();
		if (!kontak.getString("kontak", "").equals("")) {
			lm_data_user = new Gson().fromJson(kontak.getString("kontak", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		}
		map_warna = new Gson().fromJson(share.getString("warna", ""), new TypeToken<HashMap<String, Object>>(){}.getType());
		SketchwareUtil.getAllKeysFromMap(map_warna, ls_warna);
		get_data_user_ = 0;
		_join();
		_download_sticker();
		sound_pool = new SoundPool((int)(1), AudioManager.STREAM_MUSIC, 0);
		sound_sent = sound_pool.load(getApplicationContext(), R.raw.sent, 1);
		sound_receive = sound_pool.load(getApplicationContext(), R.raw.new_message, 1);
		button2.setEnabled(false);
		button2.setAlpha((float)(0.5d));
		((EditText)edittext2).setMaxLines((int)6);
		global_chat.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				lm_pesan = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						lm_pesan.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				listview1.setAdapter(new Listview1Adapter(lm_pesan));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				listview1.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL); listview1.setStackFromBottom(true);
				if (lm_pesan.size() > 0) {
					if (lm_pesan.get((int)lm_pesan.size() - 1).get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
						
					}
					else {
						sound_receive = sound_pool.play((int)(2), 1.0f, 1.0f, 1, (int)(0), 1.0f);
					}
					u = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									onChildAdded = true;
									sound = true;
								}
							});
						}
					};
					_timer.schedule(u, (int)(500));
				}
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
		if (FileUtil.isExistFile(FileUtil.getPackageDataDir(getApplicationContext()).concat("/stiker/"))) {
			
		}
		else {
			FileUtil.makeDir(FileUtil.getPackageDataDir(getApplicationContext()).concat("/stiker/"));
		}
		linear4.setVisibility(View.GONE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FP_IMG:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				img = _filePath.get((int)(0));
				imageview9.setVisibility(View.VISIBLE);
				gridview_sticker.setVisibility(View.GONE);
				imageview9.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(img, 1024, 1024));
				edittext2.setEnabled(true);
				linear5.setVisibility(View.VISIBLE);
				imageview1.setVisibility(View.GONE);
				linear4.setVisibility(View.GONE);
				hidden = true;
				SketchwareUtil.showKeyboard(getApplicationContext());
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
			sound = true;
			lm_stiker.clear();
			if (!share.getString("key sticker", "").equals("")) {
				try{
					map_sticker_downloaded = new Gson().fromJson(share.getString("key sticker", ""), new TypeToken<HashMap<String, Object>>(){}.getType());
				}catch(Exception e){
					SketchwareUtil.showMessage(getApplicationContext(), "kesalahan saat memuat ke map stiker");
				}
			}
			_download_sticker();
			_set_typing();
			_scan_sticker();
		}
		else {
			finish();
		}
		if (share.getString("stiker", "").equals("cds")) {
			try{
				lm_stiker.clear();
				lm_stiker = new Gson().fromJson(share.getString("stiker", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				gridview_sticker.setAdapter(new Gridview_stickerAdapter(lm_stiker));
				gridview_sticker.setNumColumns((int)3);
				gridview_sticker.setColumnWidth((int)SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 3);
				gridview_sticker.setVerticalSpacing((int)5);
				gridview_sticker.setHorizontalSpacing((int)5);
				gridview_sticker.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
			}catch(Exception e){
				 
			}
		}
	}
	
	@Override
	public void onStop() {
		super.onStop();
		sound = false;
	}
	
	@Override
	public void onBackPressed() {
		if (ls_stiker_url_dl.size() > 0) {
			SketchwareUtil.showMessage(getApplicationContext(), "Sticker is downloading, cannot exit");
		}
		else {
			finish();
		}
	}
	
	public void _hide_date(final double _n, final View _v) {
		_v.setVisibility(View.GONE);
		if ((_n == 0) && (lm_pesan.size() == 1)) {
			_v.setVisibility(View.VISIBLE);
		}
		if (_n == (lm_pesan.size() - 1)) {
			_v.setVisibility(View.VISIBLE);
		}
		if (!(_n == (lm_pesan.size() - 1)) && !(_n == 0)) {
			if (!lm_pesan.get((int)_n).get("uid").toString().equals(lm_pesan.get((int)_n + 1).get("uid").toString())) {
				_v.setVisibility(View.VISIBLE);
			}
		}
	}
	
	
	public void _set_bubble(final View _view, final double _position, final String _uid) {
		sedang = SketchwareUtil.getDip(getApplicationContext(), (int)(30));
		besar = SketchwareUtil.getDip(getApplicationContext(), (int)(20));
		kecil = SketchwareUtil.getDip(getApplicationContext(), (int)(8));
		warna_uid1 = "#ffffff";
		warna_uid_2 = "#ffffff";
		if (_position == 0) {
			if (lm_pesan.size() > 1) {
				if (_uid.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_uid.equals(lm_pesan.get((int)_position + 1).get("uid").toString())) {
						_advancedCorners(_view, warna_uid1, besar, sedang, sedang, kecil);
					}
					else {
						_advancedCorners(_view, warna_uid1, sedang, sedang, sedang, sedang);
					}
					_RoundandShadow(0, 2, warna_uid1, _view);
				}
				else {
					if (_uid.equals(lm_pesan.get((int)_position + 1).get("uid").toString())) {
						_advancedCorners(_view, warna_uid_2, sedang, sedang, kecil, sedang);
					}
					else {
						_advancedCorners(_view, warna_uid_2, sedang, sedang, sedang, sedang);
					}
					_RoundandShadow(0, 2, warna_uid_2, _view);
				}
			}
		}
		if (_uid.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
			_RoundandShadow(0, 2, warna_uid1, _view);
			if ((_position == 0) && (lm_pesan.size() == 1)) {
				_advancedCorners(_view, warna_uid1, besar, besar, sedang, sedang);
			}
			if ((lm_pesan.size() > 1) && (_position == (lm_pesan.size() - 1))) {
				if (_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid1, sedang, kecil, sedang, sedang);
				}
				if (!_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid1, sedang, sedang, sedang, sedang);
				}
			}
			if ((_position > 0) && (_position < (lm_pesan.size() - 1))) {
				if (!_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString()) && !_uid.equals(lm_pesan.get((int)_position + 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid1, sedang, sedang, sedang, sedang);
				}
				if (_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString()) && _uid.equals(lm_pesan.get((int)_position + 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid1, besar, kecil, besar, kecil);
				}
				if (!_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString()) && _uid.equals(lm_pesan.get((int)_position + 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid1, sedang, sedang, sedang, kecil);
				}
				if (_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString()) && !_uid.equals(lm_pesan.get((int)_position + 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid1, sedang, kecil, sedang, sedang);
				}
			}
		}
		if (!_uid.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
			_RoundandShadow(0, 2, warna_uid_2, _view);
			if ((_position == 0) && (lm_pesan.size() == 1)) {
				_advancedCorners(_view, warna_uid_2, besar, sedang, besar, sedang);
			}
			if ((lm_pesan.size() > 1) && (_position == (lm_pesan.size() - 1))) {
				if (_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid_2, kecil, sedang, sedang, sedang);
				}
				if (!_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid_2, besar, sedang, besar, sedang);
				}
			}
			if ((_position > 0) && (_position < (lm_pesan.size() - 1))) {
				if (!_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString()) && !_uid.equals(lm_pesan.get((int)_position + 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid_2, besar, sedang, besar, sedang);
				}
				if (_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString()) && _uid.equals(lm_pesan.get((int)_position + 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid_2, kecil, besar, kecil, besar);
				}
				if (!_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString()) && _uid.equals(lm_pesan.get((int)_position + 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid_2, besar, sedang, kecil, sedang);
				}
				if (_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString()) && !_uid.equals(lm_pesan.get((int)_position + 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid_2, kecil, sedang, sedang, sedang);
				}
			}
		}
	}
	
	
	public void _advancedCorners(final View _view, final String _color, final double _n1, final double _n2, final double _n3, final double _n4) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		
		gd.setCornerRadii(new float[]{(int)_n1,(int)_n1,(int)_n2,(int)_n2,(int)_n4,(int)_n4,(int)_n3,(int)_n3});
		
		_view.setBackground(gd);
	}
	
	
	public void _set_typing() {
		timer_typing = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (sound) {
							if (typing_str.equals(typing_str2)) {
								set_Subtittle = "You and ".concat(String.valueOf((long)(ls_users.size() - 1)).concat(" other users have joined the global chat"));
								getSupportActionBar().setSubtitle(set_Subtittle);
							}
							else {
								if (usernamee.equals(share.getString("username", ""))) {
									
								}
								else {
									set_Subtittle = usernamee.concat(" typing...");
									getSupportActionBar().setSubtitle(set_Subtittle);
									typing_str2 = typing_str;
								}
							}
						}
						else {
							timer_typing.cancel();
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(timer_typing, (int)(0), (int)(500));
	}
	
	
	public void _join() {
		user_in_gchat.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				lm_user_in_gchat = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						lm_user_in_gchat.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				if (lm_user_in_gchat.size() > 0) {
					map_users_in_gchat = lm_user_in_gchat.get((int)0);
					SketchwareUtil.getAllKeysFromMap(map_users_in_gchat, ls_users);
					_get_users();
					share.edit().putString("users in gchat", new Gson().toJson(map_users_in_gchat)).commit();
					if (map_users_in_gchat.containsKey(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
						
					}
					else {
						_atur_warna_saya();
					}
				}
				else {
					_atur_warna_saya();
				}
				if (ls_users.contains(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					set_Subtittle = "You and ".concat(String.valueOf((long)(ls_users.size() - 1)).concat(" other users have joined the global chat"));
					getSupportActionBar().setSubtitle(set_Subtittle);
				}
				else {
					set_Subtittle = "You and ".concat(String.valueOf((long)(ls_users.size())).concat(" other users have joined the global chat"));
					getSupportActionBar().setSubtitle(set_Subtittle);
				}
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
	}
	
	
	public void _atur_warna_saya() {
		put_warna_sya = ls_warna.get((int)(SketchwareUtil.getRandom((int)(0), (int)(ls_warna.size() - 1))));
		if (share.getString("users in gchat", "").contains(put_warna_sya)) {
			_atur_warna_saya();
		}
		else {
			put_my_color.put(FirebaseAuth.getInstance().getCurrentUser().getUid(), put_warna_sya);
			user_in_gchat.child("data").updateChildren(put_my_color);
		}
	}
	
	
	public void _text_(final TextView _textview, final String _color) {
		
		_textview.setTextColor(Color.parseColor(_color));
	}
	
	
	public void _get_users() {
		try {
			if (kontak.getString("kontak", "").contains(ls_users.get((int)(get_data_user_)))) {
				get_data_user_++;
				_get_users();
			}
			else {
				data_user.removeEventListener(_data_user_child_listener);
				data_user_str = "data user/uid/".concat(ls_users.get((int)(get_data_user_)));
				data_user = _firebase.getReference(data_user_str);
				data_user.addChildEventListener(_data_user_child_listener);
				data_user.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						lm_dataUser_temp = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								lm_dataUser_temp.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						if (lm_dataUser_temp.size() > 0) {
							map_dataUser_Temp = lm_dataUser_temp.get((int)0);
							lm_data_user.add(map_dataUser_Temp);
							get_data_user_++;
							_get_users();
						}
						else {
							get_data_user_++;
							_get_users();
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
		}
		
		catch (Exception e)
		
		{
			error = e.toString();
			kontak.edit().putString("kontak", new Gson().toJson(lm_data_user)).commit();
			_CoreProgressLoading(false);
		}
	}
	
	
	public void _CoreProgressLoading(final boolean _ifShow) {
		if (_ifShow) {
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.setMessage(null);
			coreprog.show();
			coreprog.setContentView(R.layout.custom_dialog);
		}
		else {
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	public void _RoundandShadow(final double _Radius, final double _Elevation, final String _color, final View _v) {
		float e = (float) _Elevation;
		_v.setElevation(e);
	}
	
	
	public void _Html2textview(final TextView _textview, final String _html) {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) { _textview.setText(Html.fromHtml(_html, Html.FROM_HTML_MODE_COMPACT)); } else { _textview.setText(Html.fromHtml(_html)); }
	}
	
	
	public void _set_vis(final TextView _tv, final double _poss, final View _view, final ArrayList<HashMap<String, Object>> _lm_vis) {
		_view.setVisibility(View.GONE);
		c = Calendar.getInstance();
		try{
			time_stamp.setTimeInMillis((long)(Double.parseDouble(_lm_vis.get((int)_poss).get("time stamp").toString())));
			if (_poss == 0) {
				if (new SimpleDateFormat("dd/MM/yyyy").format(c.getTime()).equals(new SimpleDateFormat("dd/MM/yyyy").format(time_stamp.getTime()))) {
					_view.setVisibility(View.GONE);
				}
				else {
					_view.setVisibility(View.VISIBLE);
					_tv.setText(new SimpleDateFormat("MMM dd, yyyy").format(time_stamp.getTime()));
				}
			}
			if (_lm_vis.size() > 1) {
				if (!(_poss == 0)) {
					try {
						cale__1.setTimeInMillis((long)(Double.parseDouble(_lm_vis.get((int)_poss).get("time stamp").toString())));
						timestamp_1.setTimeInMillis((long)(Double.parseDouble(_lm_vis.get((int)_poss - 1).get("time stamp").toString())));
						if (new SimpleDateFormat("dd/MM/yyyy").format(cale__1.getTime()).equals(new SimpleDateFormat("dd/MM/yyyy").format(timestamp_1.getTime()))) {
							_view.setVisibility(View.GONE);
						}
						else {
							if (new SimpleDateFormat("dd/MM/yyyy").format(c.getTime()).equals(new SimpleDateFormat("dd/MM/yyyy").format(cale__1.getTime()))) {
								_view.setVisibility(View.VISIBLE);
								_tv.setText("Today");
							}
							else {
								_tv.setText(new SimpleDateFormat("MMM dd, yyyy").format(cale__1.getTime()));
								_view.setVisibility(View.VISIBLE);
							}
						}
					}
					catch (Exception e)
					
					{
						error = e.toString();
						SketchwareUtil.showMessage(getApplicationContext(), error);
					}
				}
			}
		}catch(Exception e){
			 
		}
	}
	
	
	public void _setTextSize(final String _pesan, final String _jam, final TextView _tview) {
		pesan_jam = _pesan.concat(" ".concat(_jam));
		panjang_pesan = _pesan.length() + 1;
		panjang_jam = pesan_jam.length();
		_tview.setText(pesan_jam);
		_setTextViewSize(_tview, 5);
		_RelativeSize_Text(_tview, 0, panjang_pesan, 3);
		_RelativeSize_Text(_tview, panjang_pesan, pesan_jam.length(), 2);
	}
	
	
	public void _RelativeSize_Text(final TextView _textview, final double _start, final double _end, final double _size) {
		Spannable spannable = SpannableStringBuilder.valueOf(_textview.getText());
		spannable.setSpan(new android.text.style.RelativeSizeSpan((int)(_size)), (int)(_start), (int)(_end), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
		_textview.setText(spannable);
	}
	
	
	public void _setTextViewSize(final TextView _textview, final double _size) {
		_textview.setTextSize((float)_size);
	}
	
	
	public void _real_round_Shadow(final double _Radius, final double _Elevation, final String _color, final View _v) {
		float r = (float) _Radius;
		float e = (float) _Elevation;
		_v.setElevation(e);
		android.graphics.drawable.GradientDrawable s=new android.graphics.drawable.GradientDrawable();
		s.setColor(Color.parseColor(_color));
		s.setCornerRadius(r);
		_v.setBackground(s);
	}
	
	
	public void _List_Dialog(final AlertDialog.Builder _dialog, final ArrayList<String> _list) {
		final CharSequence[] _items = _list.toArray(new String[_list.size()]);
		_dialog.setItems(_items, new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				wh_ = which;
				item_ = _list.get((int)(wh_));
				if (wh_ == 0) {
					i.putExtra("uid", uid);
					i.setClass(getApplicationContext(), PesanActivity.class);
					startActivity(i);
					finish();
				}
				if (wh_ == 1) {
					i.putExtra("uid", uid);
					i.setClass(getApplicationContext(), ProfileActivity.class);
					startActivity(i);
					finish();
				}
				if (wh_ == 2) {
					((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", put_warna_sya));
					SketchwareUtil.showMessage(getApplicationContext(), "Copied to clipboard");
				}
				
			}});
	}
	
	
	public void _Set_Shadow_Effect(final TextView _text) {
		_text.setShadowLayer(1,1,1, Color.GRAY);
	}
	
	
	public void _download_sticker() {
		if (!share.getString("map stiker key", "").equals("")) {
			map_sticker_downloaded = new Gson().fromJson(share.getString("map stiker key", ""), new TypeToken<HashMap<String, Object>>(){}.getType());
			SketchwareUtil.getAllKeysFromMap(map_sticker_downloaded, ls_stiker_key);
		}
		sticker_key_.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				lm_stiker_key_temp = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						lm_stiker_key_temp.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				if (lm_stiker_key_temp.size() > 0) {
					map_stiker_key_temp = lm_stiker_key_temp.get((int)0);
					SketchwareUtil.getAllKeysFromMap(map_stiker_key_temp, ls_stiker_key_temp);
					if (ls_stiker_key_temp.size() > ls_stiker_key.size()) {
						cek_stiker = 0;
						_mulai_unduh_stiker();
					}
					else {
						
					}
				}
				else {
					
				}
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
	}
	
	
	public void _LayoutParams_Height(final View _v, final double _h) {
		_v.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, (int)_h));
	}
	
	
	public void _layout(final View _v, final double _h, final double _w) {
		_v.getLayoutParams().height = (int)_h;
		_v.getLayoutParams().width = (int)_w;
		_v.requestLayout();
	}
	
	
	public void _androidxCardView(final View _view, final double _margins, final double _cornerRadius, final double _cardElevation, final double _cardMaxElevation, final boolean _preventCornerOverlap, final String _backgroundColor, final String _rippleColor) {
		androidx.cardview.widget.CardView cv = new androidx.cardview.widget.CardView(this);
		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT); //mod by soap from betamin
		int m = (int)_margins;
		lp.setMargins(m,m,m,m);
		cv.setLayoutParams(lp);
		cv.setRadius((float)_cornerRadius);
		cv.setCardElevation((float)_cardElevation);
		cv.setMaxCardElevation((float)_cardMaxElevation);
		cv.setPreventCornerOverlap(_preventCornerOverlap);
		if(_view.getParent() instanceof LinearLayout){
			ViewGroup vg = ((ViewGroup)_view.getParent());
			vg.removeView(_view);
			vg.removeAllViews();
			vg.addView(cv);
			cv.addView(_view);
		}else{
			
		}
		
		android.graphics.drawable.RippleDrawable rippleDrawable = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor(_rippleColor)}), new android.graphics.drawable.ColorDrawable(Color.parseColor(_backgroundColor)), null);
		_view.setBackground(rippleDrawable);
		//mod by soap from betamin
		//mod by soap from betamin
	}
	
	
	public void _DG_Custom_Dialog() {
		final AlertDialog dialog2 = new AlertDialog.Builder(GlobalChatActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.dialogx, null);
		dialog2.setView(inflate);
		dialog2.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		final Button but1 = (Button) inflate.findViewById(R.id.button1);
		final LinearLayout lin1 = (LinearLayout) inflate.findViewById(R.id.linear1);
		final ImageView img1 = (ImageView) inflate.findViewById(R.id.imageview1);
		Glide.with(getApplicationContext()).load(Uri.parse("file://".concat(FileUtil.getPackageDataDir(getApplicationContext())).concat("/stiker/".concat(id_stiker_buat_d)))).into(img1);
		but1.setOnClickListener(new OnClickListener() { public void onClick(View view) {
				but1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFF90A4AE));
				
				dialog2.dismiss();
			} });
	}
	
	
	public void _mulai_unduh_stiker() {
		try{
			if (ls_stiker_key.contains(ls_stiker_key_temp.get((int)(cek_stiker)))) {
				cek_stiker++;
				_mulai_unduh_stiker();
			}
			else {
				stiker.removeEventListener(_stiker_child_listener);
				stiker_str = "stiker/".concat(ls_stiker_key_temp.get((int)(cek_stiker)));
				stiker = _firebase.getReference(stiker_str);
				stiker.addChildEventListener(_stiker_child_listener);
				stiker.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						lm_stiker_db_temp = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								lm_stiker_db_temp.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						if (lm_stiker_db_temp.size() > 0) {
							try{
								if (FileUtil.isExistFile(FileUtil.getPackageDataDir(getApplicationContext()).concat("/sticker/"))) {
									_firebase_storage.getReferenceFromUrl(lm_stiker_db_temp.get((int)0).get("stiker").toString()).getFile(new File(FileUtil.getPackageDataDir(getApplicationContext()).concat("/sticker/").concat(ls_stiker_key_temp.get((int)(cek_stiker))).concat("_temp"))).addOnSuccessListener(_stiker_fs_download_success_listener).addOnFailureListener(_stiker_fs_failure_listener).addOnProgressListener(_stiker_fs_download_progress_listener);
								}
								else {
									FileUtil.makeDir(FileUtil.getPackageDataDir(getApplicationContext()).concat("/sticker/"));
									_firebase_storage.getReferenceFromUrl(lm_stiker_db_temp.get((int)0).get("stiker").toString()).getFile(new File(FileUtil.getPackageDataDir(getApplicationContext()).concat("/sticker/").concat(ls_stiker_key_temp.get((int)(cek_stiker))).concat("_temp"))).addOnSuccessListener(_stiker_fs_download_success_listener).addOnFailureListener(_stiker_fs_failure_listener).addOnProgressListener(_stiker_fs_download_progress_listener);
								}
							}catch(Exception e){
								SketchwareUtil.showMessage(getApplicationContext(), "reee");
							}
						}
						else {
							cek_stiker++;
							SketchwareUtil.showMessage(getApplicationContext(), "skip");
							_mulai_unduh_stiker();
						}
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
		}catch(Exception e){
			SketchwareUtil.showMessage(getApplicationContext(), String.valueOf((long)(cek_stiker)));
		}
	}
	
	
	public void _roundImage(final ImageView _imageview, final double _roundValue, final boolean _isFromUrl, final String _imagePath_or_Url) {
		if (_isFromUrl) {
			Glide.with(getApplicationContext()).load(Uri.parse(_imagePath_or_Url)).into(_imageview);
			_Glide(_imageview, _imagePath_or_Url);
		}
		else {
			if (!_imagePath_or_Url.trim().equals("")) {
				
			}
			
			final Bitmap  bm = ((android.graphics.drawable.BitmapDrawable)_imageview.getDrawable()).getBitmap();
			
			_imageview.setAdjustViewBounds(true);
			_imageview.setImageBitmap(getRoundedCornerBitmap(cropToSquare(bm), (int)_roundValue));
			
		}
		
	}
	public static Bitmap cropToSquare(Bitmap bitmap){
		  int width = bitmap.getWidth();
		  int height = bitmap.getHeight();
		  int newWidth = (height > width) ? width : height;
		  int newHeight = (height > width)? height - ( height - width) : height;
		  int cropW = (width - height) / 2;
		  cropW = (cropW < 0)? 0: cropW;
		  int cropH = (height - width) / 2;
		  cropH = (cropH < 0)? 0: cropH;
		  Bitmap cropImg = Bitmap.createBitmap(bitmap, cropW, cropH, newWidth, newHeight);
		  return cropImg;
	}
	
	
	
	public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, int pixels) {
		
		int img_w=bitmap.getWidth();
		int img_h=bitmap.getHeight();
		int max_size=img_h;
		if(img_w!=img_h){
			  max_size=Math.min(img_w, img_h);
		}
		final Rect rect = new Rect(0, 0, max_size, max_size);
		
		Bitmap output = Bitmap.createBitmap(max_size, max_size, Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(output);
		final int color = 0xff00ff00;
		final Paint paint = new Paint();
		final RectF rectF = new RectF(rect);
		final float roundPx = pixels;
		paint.setAntiAlias(true);
		canvas.drawARGB(0, 0, 0, 0);
		paint.setColor(color);
		canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
		paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
		canvas.drawBitmap(bitmap, rect, rect, paint);
		return output;
	}
	
	
	public void _Glide(final ImageView _img, final String _url) {
		Glide.with(getApplicationContext()).load(Uri.parse(_url)).into(_img);
	}
	
	
	public void _scan_sticker() {
		ls_stiker_file.clear();
		lm_stiker.clear();
		FileUtil.listDir(FileUtil.getPackageDataDir(getApplicationContext()).concat("/sticker/".concat("")), ls_stiker_file);
		cari_stiker = 0;
		for(int _repeat88 = 0; _repeat88 < (int)(ls_stiker_file.size()); _repeat88++) {
			if (map_sticker_downloaded.containsKey(Uri.parse(ls_stiker_file.get((int)(cari_stiker))).getLastPathSegment())) {
				{
					HashMap<String, Object> _item = new HashMap<>();
					_item.put("stiker", ls_stiker_file.get((int)(cari_stiker)));
					lm_stiker.add(_item);
				}
				
			}
			cari_stiker++;
			gridview_sticker.setAdapter(new Gridview_stickerAdapter(lm_stiker));
			gridview_sticker.setNumColumns((int)3);
			gridview_sticker.setColumnWidth((int)SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 3);
			gridview_sticker.setVerticalSpacing((int)5);
			gridview_sticker.setHorizontalSpacing((int)5);
			gridview_sticker.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
		}
	}
	
	
	public void _stiker_tool() {
		if (!share.getString("map stiker key", "").equals("")) {
			try{
				map_sticker_downloaded = new Gson().fromJson(share.getString("map stiker key", ""), new TypeToken<HashMap<String, Object>>(){}.getType());
			}catch(Exception e){
				SketchwareUtil.showMessage(getApplicationContext(), "kesalahan saat memuat ke map stiker");
			}
		}
	}
	
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		int style = 0;
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					
					if (((TextView) v).getTypeface().getStyle()==Typeface.NORMAL) {
						
						style = 0;
						
					}else{
						
						if (((TextView) v).getTypeface().getStyle()==Typeface.BOLD) {
							
							style = 1;
							
						}else{
							
							if (((TextView) v).getTypeface().getStyle()==Typeface.ITALIC) {
								
								style = 2;
								
							}else{
								
								if (((TextView) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
									
									style = 3;
									
								}}}}
					
					((TextView) v).setTypeface(typeace, (style));
					
				}
				else {
					if ((v instanceof EditText )) {
						if (((EditText) v).getTypeface().getStyle()==Typeface.NORMAL) {
							
							style = 0;
							
						}else{
							
							if (((EditText) v).getTypeface().getStyle()==Typeface.BOLD) {
								
								style = 1;
								
							}else{
								
								if (((EditText) v).getTypeface().getStyle()==Typeface.ITALIC) {
									
									style = 2;
									
								}else{
									
									if (((EditText) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
										
										style = 3;
										
									}}}}
						
						((EditText) v).setTypeface(typeace, (style));
					}
					else {
						if ((v instanceof RadioButton )) {
							if (((RadioButton) v).getTypeface().getStyle()==Typeface.NORMAL) {
								
								style = 0;
								
							}else{
								
								if (((RadioButton) v).getTypeface().getStyle()==Typeface.BOLD) {
									
									style = 1;
									
								}else{
									
									if (((RadioButton) v).getTypeface().getStyle()==Typeface.ITALIC) {
										
										style = 2;
										
									}else{
										
										if (((RadioButton) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
											
											style = 3;
											
										}}}}
							
							((RadioButton) v).setTypeface(typeace, (style));
						}
						else {
							if ((v instanceof CheckBox )) {
								if (((CheckBox) v).getTypeface().getStyle()==Typeface.NORMAL) {
									
									style = 0;
									
								}else{
									
									if (((CheckBox) v).getTypeface().getStyle()==Typeface.BOLD) {
										
										style = 1;
										
									}else{
										
										if (((CheckBox) v).getTypeface().getStyle()==Typeface.ITALIC) {
											
											style = 2;
											
										}else{
											
											if (((CheckBox) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
												
												style = 3;
												
											}}}}
								
								((CheckBox) v).setTypeface(typeace, (style));
							}
							else {
								if ((v instanceof Switch )) {
									if (((Switch) v).getTypeface().getStyle()==Typeface.NORMAL) {
										
										style = 0;
										
									}else{
										
										if (((Switch) v).getTypeface().getStyle()==Typeface.BOLD) {
											
											style = 1;
											
										}else{
											
											if (((Switch) v).getTypeface().getStyle()==Typeface.ITALIC) {
												
												style = 2;
												
											}else{
												
												if (((Switch) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
													
													style = 3;
													
												}}}}
									
									((Switch) v).setTypeface(typeace, (style));
								}
								else {
									if ((v instanceof Button)) {
										if (((Button) v).getTypeface().getStyle()==Typeface.NORMAL) {
											
											style = 0;
											
										}else{
											
											if (((Button) v).getTypeface().getStyle()==Typeface.BOLD) {
												
												style = 1;
												
											}else{
												
												if (((Button) v).getTypeface().getStyle()==Typeface.ITALIC) {
													
													style = 2;
													
												}else{
													
													if (((Button) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
														
														style = 3;
														
													}}}}
										
										((Button) v).setTypeface(typeace, (style));
									}
								}
							}
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	public void _hide_username(final TextView _textview_username, final double _position, final String _uid) {
		_textview_username.setVisibility(View.GONE);
		if (_position == 0) {
			_textview_username.setVisibility(View.VISIBLE);
		}
		else {
			if (lm_pesan.get((int)_position).get("uid").toString().equals(lm_pesan.get((int)_position - 1).get("uid").toString())) {
				_textview_username.setVisibility(View.GONE);
			}
			else {
				_textview_username.setVisibility(View.VISIBLE);
			}
		}
	}
	
	
	public void _block(final View _linear, final TextView _text, final double _position) {
		if (lm_pesan.get((int)_position).containsKey("block")) {
			_text.setText(lm_pesan.get((int)_position).get("username").toString().concat(" has blocked from global chat".concat("")));
			_linear.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)2, 0xFFD32F2F, 0xFFFFFFFF));
			_linear.setVisibility(View.VISIBLE);
		}
		else {
			_linear.setVisibility(View.GONE);
		}
	}
	
	
	public void _popup_menu(final View _view, final double _position) {
		//change the activity if mainactivity is not yours
		
		PopupMenu popup = new PopupMenu(GlobalChatActivity.this, _view);
		Menu menu = popup.getMenu();
		//add menu or change the name
		// you will change the name in the different case or add other cases in the blocks below
		
		menu.add("Copy");
		menu.add("Reply");
		menu.add("Report");
		if (FirebaseAuth.getInstance().getCurrentUser().getEmail().equals("made.swd@gmail.com")) {
			menu.add("Delete");
			menu.add("Block");
		}
		popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener(){
			@Override
			public boolean onMenuItemClick(MenuItem item){
				switch (item.getTitle().toString()){
					case "Reply":
					SketchwareUtil.showMessage(getApplicationContext(), "Coming soon...");
					break;
					case "Copy":
					SketchwareUtil.showMessage(getApplicationContext(), "Copied to clipboard");
					((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", lm_pesan.get((int)_position).get("pesan").toString()));
					break;
					case "Report":
					break;
					case "Delete":
					global_chat.child(lm_pesan.get((int)_position).get("push key").toString()).removeValue();
					SketchwareUtil.showMessage(getApplicationContext(), "Pesan dihapus");
					break;
					case "Block":
					push_data_blocked.put(lm_pesan.get((int)_position).get("uid").toString(), "blocked");
					user_in_gchat.child("data").updateChildren(push_data_blocked);
					c = Calendar.getInstance();
					push_key = global_chat.push().getKey();
					c = Calendar.getInstance();
					map_pesan = new HashMap<>();
					map_pesan.put("pesan", "");
					map_pesan.put("blocked", lm_pesan.get((int)_position).get("uid").toString());
					map_pesan.put("tanggal", new SimpleDateFormat("MMM dd, yyyy").format(c.getTime()));
					map_pesan.put("jam", new SimpleDateFormat("HH:mm").format(c.getTime()));
					map_pesan.put("gmt", new SimpleDateFormat("ZZZZ").format(c.getTime()));
					map_pesan.put("reply", "");
					map_pesan.put("reply id", "");
					map_pesan.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
					map_pesan.put("username", lm_pesan.get((int)_position).get("username").toString());
					map_pesan.put("id stiker", "");
					map_pesan.put("push key", push_key);
					map_pesan.put("time stamp", String.valueOf((long)(c.getTimeInMillis())));
					global_chat.child(push_key).updateChildren(map_pesan);
					break;
				}
				return true;
				
			}
		});
		popup.show();
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.pesanf, null);
			}
			
			final LinearLayout blocked_linear_info = _view.findViewById(R.id.blocked_linear_info);
			final LinearLayout linear7 = _view.findViewById(R.id.linear7);
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear_tgl = _view.findViewById(R.id.linear_tgl);
			final TextView blocked_text_info = _view.findViewById(R.id.blocked_text_info);
			final TextView textview5 = _view.findViewById(R.id.textview5);
			final LinearLayout linear_pesan = _view.findViewById(R.id.linear_pesan);
			final LinearLayout dasar_reply_0 = _view.findViewById(R.id.dasar_reply_0);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear_garis = _view.findViewById(R.id.linear_garis);
			final LinearLayout dasar_reply = _view.findViewById(R.id.dasar_reply);
			final TextView username_rep = _view.findViewById(R.id.username_rep);
			final TextView pesan_rep = _view.findViewById(R.id.pesan_rep);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final TextView textview6 = _view.findViewById(R.id.textview6);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final LinearLayout linear8 = _view.findViewById(R.id.linear8);
			final com.jgabrielfreitas.core.BlurImageView image = _view.findViewById(R.id.image);
			final ImageView sticker = _view.findViewById(R.id.sticker);
			final TextView tanggal = _view.findViewById(R.id.tanggal);
			
			if (_data.get((int)_position).containsKey("blocked")) {
				linear1.setVisibility(View.GONE);
				linear_tgl.setVisibility(View.INVISIBLE);
				blocked_text_info.setText(lm_pesan.get((int)_position).get("username").toString().concat(" has blocked from global chat".concat("")));
				blocked_linear_info.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)2, 0xFFD32F2F, 0xFFFFFFFF));
				blocked_linear_info.setVisibility(View.VISIBLE);
				linear7.setVisibility(View.GONE);
			}
			else {
				textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
				username_rep.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
				pesan_rep.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
				textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
				tanggal.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
				sticker.setVisibility(View.GONE);
				image.setVisibility(View.GONE);
				sticker.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						
					}
				});
				dasar_reply_0.setVisibility(View.GONE);
				linear2.setVisibility(View.GONE);
				c = Calendar.getInstance();
				_real_round_Shadow(50, 4, "#ffffff", linear7);
				_hide_date(_position, linear_tgl);
				
				try {
					if (lm_pesan.get((int)_position).containsKey("pesan")) {
						textview2.setText(lm_pesan.get((int)_position).get("pesan").toString());
						_set_vis(textview5, _position, linear7, lm_pesan);
						ts.setTimeInMillis((long)(Double.parseDouble(lm_pesan.get((int)_position).get("time stamp").toString())));
						_setTextSize(lm_pesan.get((int)_position).get("pesan").toString(), new SimpleDateFormat("HH:mm").format(ts.getTime()), textview2);
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "tidak ada key pesan");
					}
				}
				
				catch (Exception e)
				{
					error = e.toString();
					SketchwareUtil.showMessage(getApplicationContext(), "");
				}
				try {
					if (lm_pesan.get((int)_position).containsKey("tanggal")) {
						tanggal.setText(lm_pesan.get((int)_position).get("tanggal").toString());
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "tanggal tidak ada");
					}
				}
				
				catch (Exception e)
				{
					error = e.toString();
					SketchwareUtil.showMessage(getApplicationContext(), "");
				}
				if (lm_pesan.get((int)_position).containsKey("uid")) {
					tanggal.setText("");
					if (new SimpleDateFormat("dd/MM/yyyy").format(c.getTime()).equals(lm_pesan.get((int)_position).get("tanggal").toString())) {
						tanggal.setText("");
					}
					linear5.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
					if (lm_pesan.get((int)_position).get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
						linear1.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
						linear_tgl.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
						textview3.setShadowLayer(0,0,0, Color.BLACK);
						linear1.setPadding(150,0,20,0);
						textview2.setPadding(32,4,8,4);
						if (new SimpleDateFormat("dd/MM/yyyy").format(c.getTime()).equals(lm_pesan.get((int)_position).get("tanggal").toString())) {
							tanggal.setText("sent".concat(" • ".concat(lm_pesan.get((int)_position).get("jam").toString())));
						}
						linear5.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
					}
					else {
						linear1.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);
						linear_tgl.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);
						linear1.setPadding(20,0,150,0);
						_Set_Shadow_Effect(textview3);
					}
				}
				else {
					
				}
				blocked_linear_info.setVisibility(View.GONE);
				try {
					_text_(textview3, map_users_in_gchat.get(lm_pesan.get((int)_position).get("uid").toString()).toString());
				}
				
				catch (Exception e)
				{
					error = e.toString();
				}
				
				textview2.setTextColor(Color.parseColor("#000000"));
				if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(lm_pesan.get((int)_position).get("uid").toString())) {
					
					textview3.setTextColor(Color.parseColor("#000000"));
					
				}
				textview3.setText(lm_pesan.get((int)_position).get("uid").toString());
				get_username = 0;
				for(int _repeat206 = 0; _repeat206 < (int)(lm_data_user.size()); _repeat206++) {
					if (lm_pesan.get((int)_position).get("uid").toString().equals(lm_data_user.get((int)get_username).get("uid").toString())) {
						textview3.setText(lm_data_user.get((int)get_username).get("username").toString());
					}
					get_username++;
				}
				_set_bubble(linear_pesan, _position, lm_pesan.get((int)_position).get("uid").toString());
				textview6.setVisibility(View.GONE);
				if (lm_pesan.get((int)_position).containsKey("id stiker")) {
					if (_data.get((int)_position).get("id stiker").toString().equals("")) {
						textview2.setVisibility(View.VISIBLE);
					}
					else {
						sticker.setVisibility(View.VISIBLE);
						if (map_sticker_downloaded.containsKey(lm_pesan.get((int)_position).get("id stiker").toString())) {
							Glide.with(getApplicationContext()).load(Uri.parse("file://".concat(FileUtil.getPackageDataDir(getApplicationContext())).concat("/sticker/".concat(lm_pesan.get((int)_position).get("id stiker").toString())))).into(sticker);
						}
						else {
							sticker.setImageResource(R.drawable.ditempat);
						}
						linear_pesan.setBackgroundColor(Color.TRANSPARENT);
						textview6.setVisibility(View.VISIBLE);
						ts.setTimeInMillis((long)(Double.parseDouble(lm_pesan.get((int)_position).get("time stamp").toString())));
						textview6.setText(new SimpleDateFormat("HH:mm").format(ts.getTime()));
						textview6.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)100, (int)0, 0xFF000000, 0xFFFFFFFF));
						float radius = 0f;
						cardview1.setRadius(radius);
						cardview1.setCardBackgroundColor(Color.TRANSPARENT);
						textview2.setVisibility(View.GONE);
					}
				}
				else {
					textview2.setVisibility(View.VISIBLE);
				}
				if (lm_pesan.get((int)_position).containsKey("gambar")) {
					if (!lm_pesan.get((int)_position).get("gambar").toString().equals("")) {
						image.setVisibility(View.VISIBLE);
						cardview1.setVisibility(View.VISIBLE);
						sticker.setVisibility(View.GONE);
						Glide.with(getApplicationContext()).load(Uri.parse(lm_pesan.get((int)_position).get("gambar").toString())).into(image);
						
					}
				}
				else {
					
				}
				//👇hide username
				if (_position == 0) {
					linear6.setVisibility(View.VISIBLE);
				}
				else {
					if (lm_pesan.get((int)_position).get("uid").toString().equals(lm_pesan.get((int)_position - 1).get("uid").toString())) {
						linear6.setVisibility(View.GONE);
					}
					else {
						linear6.setVisibility(View.VISIBLE);
					}
				}
				linear1.setOnLongClickListener(new View.OnLongClickListener() {
					@Override
					public boolean onLongClick(View _view) {
						_popup_menu(linear_pesan, _position);
						return true;
					}
				});
			}
			
			return _view;
		}
	}
	
	public class Gridview_stickerAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview_stickerAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.stiker_c, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			
			_Glide(imageview1, "file://".concat(_data.get((int)_position).get("stiker").toString()));
			_androidxCardView(linear1, 3, 20, 2, 3, false, "#ffffff", "#eeeeee");
			_layout(imageview1, (SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 3) - 20, (SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 3) - 20);
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}