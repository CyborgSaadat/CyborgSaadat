package com.scloud.chat;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.jgabrielfreitas.core.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class UpdateActivity extends AppCompatActivity {
	
	private HashMap<String, Object> map_update_data = new HashMap<>();
	private String fontName = "";
	private String typeace = "";
	
	private LinearLayout linear1;
	private LinearLayout linear4;
	private ScrollView vscroll1;
	private Button button1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private ImageView imageview1;
	private ImageView imageview2;
	private TextView textview1;
	private TextView textview2;
	private TextView textview3;
	
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.update);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear4 = findViewById(R.id.linear4);
		vscroll1 = findViewById(R.id.vscroll1);
		button1 = findViewById(R.id.button1);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		imageview1 = findViewById(R.id.imageview1);
		imageview2 = findViewById(R.id.imageview2);
		textview1 = findViewById(R.id.textview1);
		textview2 = findViewById(R.id.textview2);
		textview3 = findViewById(R.id.textview3);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (map_update_data.get("judul").toString().equals("update")) {
					i.setData(Uri.parse(map_update_data.get("url").toString()));
					((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", map_update_data.get("url").toString()));
					i.setAction(Intent.ACTION_VIEW);
					startActivity(i);
				}
				else {
					if (map_update_data.get("skip").toString().equals("yes")) {
						
						startActivity(i);
						finish();
					}
					else {
						finish();
					}
				}
			}
		});
	}
	
	private void initializeLogic() {
		setTitle("Update");
		_RoundAndBorder(vscroll1, "#ffffff", 0, "#cfd8dc", 8);
		_RoundandShadow(0, 8, "#ffffff", linear4);
		_RoundandShadow(100, 8, "#37474f", button1);
		map_update_data = new Gson().fromJson(getIntent().getStringExtra("extraData"), new TypeToken<HashMap<String, Object>>(){}.getType());
		try{
			textview3.setText(map_update_data.get("keterangan update").toString());
			if (map_update_data.get("judul").toString().equals("update")) {
				imageview2.setColorFilter(0xFF43A047, PorterDuff.Mode.MULTIPLY);
				textview2.setText("V".concat(map_update_data.get("version").toString()));
				textview1.setText("ABOUT UPDATE");
			}
			else {
				imageview2.setVisibility(View.GONE);
				imageview2.setImageResource(R.drawable.ic_notifications_on_white);
				imageview2.setColorFilter(0xFF9E9E9E, PorterDuff.Mode.MULTIPLY);
				textview1.setText("INFO");
			}
			if (map_update_data.get("url").toString().equals("")) {
				button1.setVisibility(View.GONE);
			}
		}catch(Exception e){
			textview3.setText(getIntent().getStringExtra("extraData"));
		}
		if (map_update_data.containsKey("pesan singkat")) {
			button1.setVisibility(View.GONE);
			imageview2.setVisibility(View.VISIBLE);
			imageview2.setImageResource(R.drawable.ic_notifications_on_white);
			imageview2.setColorFilter(0xFF212121, PorterDuff.Mode.MULTIPLY);
			textview1.setText("Info");
			textview2.setVisibility(View.GONE);
			imageview2.setRotation((float)(0));
			textview3.setText(map_update_data.get("pesan panjang").toString());
		}
		_changeActivityFont("font");
	}
	
	public void _RoundandShadow(final double _Radius, final double _Elevation, final String _color, final View _v) {
		float r = (float) _Radius;
		float e = (float) _Elevation;
		_v.setElevation(e);
		android.graphics.drawable.GradientDrawable s=new android.graphics.drawable.GradientDrawable();
		s.setColor(Color.parseColor(_color));
		s.setCornerRadius(r);
		_v.setBackground(s);
	}
	
	
	public void _RoundAndBorder(final View _view, final String _color1, final double _border, final String _color2, final double _round) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color1));
		gd.setCornerRadius((int) _round);
		gd.setStroke((int) _border, Color.parseColor(_color2));
		_view.setBackground(gd);
	}
	
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		int style = 0;
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					
					if (((TextView) v).getTypeface().getStyle()==Typeface.NORMAL) {
						
						style = 0;
						
					}else{
						
						if (((TextView) v).getTypeface().getStyle()==Typeface.BOLD) {
							
							style = 1;
							
						}else{
							
							if (((TextView) v).getTypeface().getStyle()==Typeface.ITALIC) {
								
								style = 2;
								
							}else{
								
								if (((TextView) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
									
									style = 3;
									
								}}}}
					
					((TextView) v).setTypeface(typeace, (style));
					
				}
				else {
					if ((v instanceof EditText )) {
						if (((EditText) v).getTypeface().getStyle()==Typeface.NORMAL) {
							
							style = 0;
							
						}else{
							
							if (((EditText) v).getTypeface().getStyle()==Typeface.BOLD) {
								
								style = 1;
								
							}else{
								
								if (((EditText) v).getTypeface().getStyle()==Typeface.ITALIC) {
									
									style = 2;
									
								}else{
									
									if (((EditText) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
										
										style = 3;
										
									}}}}
						
						((EditText) v).setTypeface(typeace, (style));
					}
					else {
						if ((v instanceof RadioButton )) {
							if (((RadioButton) v).getTypeface().getStyle()==Typeface.NORMAL) {
								
								style = 0;
								
							}else{
								
								if (((RadioButton) v).getTypeface().getStyle()==Typeface.BOLD) {
									
									style = 1;
									
								}else{
									
									if (((RadioButton) v).getTypeface().getStyle()==Typeface.ITALIC) {
										
										style = 2;
										
									}else{
										
										if (((RadioButton) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
											
											style = 3;
											
										}}}}
							
							((RadioButton) v).setTypeface(typeace, (style));
						}
						else {
							if ((v instanceof CheckBox )) {
								if (((CheckBox) v).getTypeface().getStyle()==Typeface.NORMAL) {
									
									style = 0;
									
								}else{
									
									if (((CheckBox) v).getTypeface().getStyle()==Typeface.BOLD) {
										
										style = 1;
										
									}else{
										
										if (((CheckBox) v).getTypeface().getStyle()==Typeface.ITALIC) {
											
											style = 2;
											
										}else{
											
											if (((CheckBox) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
												
												style = 3;
												
											}}}}
								
								((CheckBox) v).setTypeface(typeace, (style));
							}
							else {
								if ((v instanceof Switch )) {
									if (((Switch) v).getTypeface().getStyle()==Typeface.NORMAL) {
										
										style = 0;
										
									}else{
										
										if (((Switch) v).getTypeface().getStyle()==Typeface.BOLD) {
											
											style = 1;
											
										}else{
											
											if (((Switch) v).getTypeface().getStyle()==Typeface.ITALIC) {
												
												style = 2;
												
											}else{
												
												if (((Switch) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
													
													style = 3;
													
												}}}}
									
									((Switch) v).setTypeface(typeace, (style));
								}
								else {
									if ((v instanceof Button)) {
										if (((Button) v).getTypeface().getStyle()==Typeface.NORMAL) {
											
											style = 0;
											
										}else{
											
											if (((Button) v).getTypeface().getStyle()==Typeface.BOLD) {
												
												style = 1;
												
											}else{
												
												if (((Button) v).getTypeface().getStyle()==Typeface.ITALIC) {
													
													style = 2;
													
												}else{
													
													if (((Button) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
														
														style = 3;
														
													}}}}
										
										((Button) v).setTypeface(typeace, (style));
									}
								}
							}
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}