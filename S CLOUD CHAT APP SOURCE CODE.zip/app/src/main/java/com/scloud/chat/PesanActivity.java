package com.scloud.chat;

import android.animation.*;
import android.animation.ObjectAnimator;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.jgabrielfreitas.core.*;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class PesanActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private String str = "";
	private String chat_str = "";
	private String uid2 = "";
	private String chat_str_2 = "";
	private double get_message = 0;
	private HashMap<String, Object> map_get_pesan = new HashMap<>();
	private double besar = 0;
	private double kecil = 0;
	private String warna_uid1 = "";
	private String warna_uid_2 = "";
	private boolean onchildAdded = false;
	private double length = 0;
	private double place = 0;
	private double get_username = 0;
	private HashMap<String, Object> map_pesan = new HashMap<>();
	private String push_key = "";
	private String pesan_ = "";
	private String listchat_u1 = "";
	private String listchat_u2 = "";
	private String error = "";
	private HashMap<String, Object> map_key_u2 = new HashMap<>();
	private double sound_sent = 0;
	private double sound_receive = 0;
	private double s1 = 0;
	private double s2 = 0;
	private HashMap<String, Object> map_key_pesan = new HashMap<>();
	private boolean get_messages = false;
	private HashMap<String, Object> map_user_project = new HashMap<>();
	private String data_user_str = "";
	private HashMap<String, Object> map_user_info = new HashMap<>();
	private HashMap<String, Object> nap_user_id = new HashMap<>();
	private String typing_str = "";
	private HashMap<String, Object> map_add_user = new HashMap<>();
	private String typing_u2_str = "";
	private String after = "";
	private String before = "";
	private HashMap<String, Object> map_typing = new HashMap<>();
	private boolean finish = false;
	private String last_seen_str = "";
	private String last_seen_u2_str = "";
	private HashMap<String, Object> map_last_seen = new HashMap<>();
	private boolean last_seen_ = false;
	private boolean online = false;
	private String pesan_jam = "";
	private double panjang_pesan = 0;
	private double panjang_jam = 0;
	private boolean sent_byMe = false;
	private double tes = 0;
	private HashMap<String, Object> pushKey_pesan = new HashMap<>();
	private String username_ = "";
	private boolean reply = false;
	private String last_seen__ = "";
	private HashMap<String, Object> map_sent_read = new HashMap<>();
	private boolean typing_ = false;
	private double typing_num = 0;
	private boolean trigger = false;
	private String s = "";
	private String fontName = "";
	private String typeace = "";
	private String typing_str2 = "";
	private String set_Subtittle = "";
	private String usernamee = "";
	private String ts_online = "";
	private String ts_online2 = "";
	private double n_ts_online = 0;
	private boolean b_timer = false;
	private String typing_str1 = "";
	
	private ArrayList<HashMap<String, Object>> lm_listchat_temp = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_pesan = new ArrayList<>();
	private ArrayList<String> ls = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_data_user = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_test = new ArrayList<>();
	private ArrayList<String> ls_tedt = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_user_project = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_data_user_temp = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_typing = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_last_seen = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_users = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_comment = new ArrayList<>();
	
	private LinearLayout linear1;
	private ListView listview1;
	private LinearLayout linear5;
	private LinearLayout linear3;
	private LinearLayout dasar_reply_0;
	private ImageView imageview2;
	private LinearLayout linear_garis;
	private LinearLayout dasar_reply;
	private ImageView imageview3;
	private TextView username_rep;
	private TextView pesan_rep;
	private LinearLayout linear2;
	private EditText edittext2;
	private Button button2;
	
	private DatabaseReference chat = _firebase.getReference(""+chat_str+"");
	private ChildEventListener _chat_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference chat_2 = _firebase.getReference(""+chat_str_2+"");
	private ChildEventListener _chat_2_child_listener;
	private TimerTask tim;
	private SharedPreferences share;
	private Calendar c = Calendar.getInstance();
	private SharedPreferences pesan;
	private DatabaseReference listChatU1 = _firebase.getReference(""+listchat_u1+"");
	private ChildEventListener _listChatU1_child_listener;
	private DatabaseReference listChatU2 = _firebase.getReference(""+listchat_u2+"");
	private ChildEventListener _listChatU2_child_listener;
	private SoundPool sound;
	private MediaPlayer mp;
	private ObjectAnimator anim = new ObjectAnimator();
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	private Intent i = new Intent();
	private DatabaseReference data_user = _firebase.getReference(""+data_user_str+"");
	private ChildEventListener _data_user_child_listener;
	private SharedPreferences kontak;
	private DatabaseReference typing = _firebase.getReference(""+typing_str+"");
	private ChildEventListener _typing_child_listener;
	private DatabaseReference typing_u2 = _firebase.getReference(""+typing_u2_str+"");
	private ChildEventListener _typing_u2_child_listener;
	private TimerTask t2;
	private DatabaseReference last_seen = _firebase.getReference(""+last_seen_str+"");
	private ChildEventListener _last_seen_child_listener;
	private DatabaseReference last_seen_u2 = _firebase.getReference(""+last_seen_u2_str+"");
	private ChildEventListener _last_seen_u2_child_listener;
	private Calendar ts = Calendar.getInstance();
	private Calendar cal_last_seen = Calendar.getInstance();
	private Calendar c_typing = Calendar.getInstance();
	private Calendar tss = Calendar.getInstance();
	private Calendar ts_1 = Calendar.getInstance();
	private TimerTask timer_typing;
	private TimerTask timer_online;
	private SharedPreferences last_typing;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.pesan);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = findViewById(R.id.linear1);
		listview1 = findViewById(R.id.listview1);
		linear5 = findViewById(R.id.linear5);
		linear3 = findViewById(R.id.linear3);
		dasar_reply_0 = findViewById(R.id.dasar_reply_0);
		imageview2 = findViewById(R.id.imageview2);
		linear_garis = findViewById(R.id.linear_garis);
		dasar_reply = findViewById(R.id.dasar_reply);
		imageview3 = findViewById(R.id.imageview3);
		username_rep = findViewById(R.id.username_rep);
		pesan_rep = findViewById(R.id.pesan_rep);
		linear2 = findViewById(R.id.linear2);
		edittext2 = findViewById(R.id.edittext2);
		button2 = findViewById(R.id.button2);
		auth = FirebaseAuth.getInstance();
		share = getSharedPreferences("share", Activity.MODE_PRIVATE);
		pesan = getSharedPreferences("pesan", Activity.MODE_PRIVATE);
		net = new RequestNetwork(this);
		kontak = getSharedPreferences("kontak", Activity.MODE_PRIVATE);
		last_typing = getSharedPreferences("last_typing", Activity.MODE_PRIVATE);
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (lm_pesan.get((int)_position).containsKey("project id")) {
					_get_project(lm_pesan.get((int)_position).get("project id").toString(), _position);
				}
			}
		});
		
		listview1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", lm_pesan.get((int)_position).get("pesan").toString()));
				SketchwareUtil.showMessage(getApplicationContext(), "copied to clipboard");
				return true;
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear5.setVisibility(View.GONE);
				reply = false;
			}
		});
		
		edittext2.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				button2.setEnabled(false);
				anim.setTarget(button2);
				anim.setPropertyName("alpha");
				anim.setFloatValues((float)(0.5d));
				anim.setDuration((int)(100));
				anim.setRepeatMode(ValueAnimator.RESTART);
				anim.setRepeatCount((int)(0));
				anim.setInterpolator(new LinearInterpolator());
				anim.start();
				if (_charSeq.trim().length() > 0) {
					button2.setEnabled(true);
					anim.setTarget(button2);
					anim.setPropertyName("alpha");
					anim.setFloatValues((float)(1));
					anim.setDuration((int)(100));
					anim.setRepeatMode(ValueAnimator.RESTART);
					anim.setRepeatCount((int)(0));
					anim.setInterpolator(new LinearInterpolator());
					anim.start();
				}
				pesan_ = _charSeq;
				if (_charSeq.trim().length() > 0) {
					c = Calendar.getInstance();
					s = String.valueOf((long)(c.getTimeInMillis()));
					map_typing.put("typing", c.getTimeInMillis());
					typing.child("ims").updateChildren(map_typing);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				button2.setAlpha((float)(0.6d));
				button2.setEnabled(false);
				button2.setText("sending...");
				c = Calendar.getInstance();
				push_key = chat.push().getKey();
				map_pesan.put("pesan", pesan_);
				map_pesan.put("tanggal", new SimpleDateFormat("MMM dd, yyyy").format(c.getTime()));
				map_pesan.put("jam", new SimpleDateFormat("HH:mm").format(c.getTime()));
				map_pesan.put("gmt", new SimpleDateFormat("ZZZZ").format(c.getTime()));
				map_pesan.put("time stamp", String.valueOf((long)(c.getTimeInMillis())));
				if (reply) {
					
				}
				else {
					map_pesan.put("reply uid", "");
					map_pesan.put("reply id", "");
				}
				map_pesan.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				map_pesan.put("push key", push_key);
				chat.child(push_key).updateChildren(map_pesan);
				chat_2.child(push_key).updateChildren(map_pesan);
				map_pesan.put("uid2", uid2);
				listChatU1.child(uid2).updateChildren(map_pesan);
				map_pesan.put("uid2", FirebaseAuth.getInstance().getCurrentUser().getUid());
				listChatU2.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map_pesan);
				edittext2.setText("");
				button2.setAlpha((float)(0.5d));
				button2.setText("send");
				map_pesan.clear();
				reply = false;
				sent_byMe = false;
				linear5.setVisibility(View.GONE);
			}
		});
		
		_chat_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (onchildAdded) {
					if (!map_key_pesan.containsKey(_childValue.get("push key").toString())) {
						map_key_pesan.put(_childValue.get("push key").toString(), _childValue.get("pesan").toString());
						lm_pesan.add(_childValue);
						chat.child(_childValue.get("push key").toString()).removeValue();
						share.edit().putString("map key pesan", new Gson().toJson(map_key_pesan)).commit();
						pesan.edit().putString(uid2, new Gson().toJson(lm_pesan)).commit();
						share.edit().putString(uid2, lm_pesan.get((int)lm_pesan.size() - 1).get("push key").toString()).commit();
						lm_listchat_temp.clear();
						if (lm_pesan.get((int)lm_pesan.size() - 1).get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							sound_sent = sound.play((int)(1), 1.0f, 1.0f, 1, (int)(0), 1.0f);
						}
						else {
							sound_receive = sound.play((int)(2), 1.0f, 1.0f, 1, (int)(0), 1.0f);
						}
						share.edit().putString("key list chat", lm_pesan.get((int)lm_pesan.size() - 1).get("push key").toString()).commit();
						_SortMap(lm_pesan, "push key", false, true);
						listview1.setAdapter(new Listview1Adapter(lm_pesan));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
						listview1.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL); listview1.setStackFromBottom(true);
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		chat.addChildEventListener(_chat_child_listener);
		
		_chat_2_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				map_sent_read.put(_childKey, "uid2");
				share.edit().putString("key".concat(uid2), new Gson().toJson(map_sent_read)).commit();
				_SortMap(lm_pesan, "push key", false, true);
				if (onchildAdded) {
					if (sent_byMe) {
						int _index =listview1.getFirstVisiblePosition();
						View _view = listview1.getChildAt(0);
						int _top = (_view == null) ? 0 : _view.getTop();
						listview1.setAdapter(new Listview1Adapter(lm_pesan));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
						listview1.setSelectionFromTop(_index,_top);
						listview1.smoothScrollToPosition((int)(lm_pesan.size() - 1));
						sent_byMe = false;
					}
					else {
						int _index =listview1.getFirstVisiblePosition();
						
						tes = _index;
						if ((lm_pesan.size() - tes) < 11) {
							int _index2 =listview1.getFirstVisiblePosition();
							
							View _view = listview1.getChildAt(0);
							int _bottom = (_view == null) ? 0 : _view.getTop();
							listview1.setAdapter(new Listview1Adapter(lm_pesan));
							((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
							listview1.setSelectionFromTop(_index2,_bottom);
							listview1.smoothScrollToPosition((int)(lm_pesan.size() - 1));
						}
						else {
							int _index1 =listview1.getFirstVisiblePosition();
							View _view = listview1.getChildAt(0);
							int _top = (_view == null) ? 0 : _view.getTop();
							listview1.setAdapter(new Listview1Adapter(lm_pesan));
							((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
							listview1.setSelectionFromTop(_index1,_top);
						}
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				map_key_u2.clear();
				map_key_u2.put(_childKey, "uid2");
				share.edit().putString("key".concat(uid2), new Gson().toJson(map_key_u2)).commit();
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				map_sent_read.clear();
				share.edit().putString("key".concat(uid2), new Gson().toJson(map_key_u2)).commit();
				_SortMap(lm_pesan, "push key", false, true);
				int _index =listview1.getFirstVisiblePosition();
				View _view = listview1.getChildAt(0);
				int _top = (_view == null) ? 0 : _view.getTop();
				listview1.setAdapter(new Listview1Adapter(lm_pesan));
				((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
				listview1.setSelectionFromTop(_index,_top);
				listview1.smoothScrollToPosition((int)(lm_pesan.size() - 1));
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				SketchwareUtil.showMessage(getApplicationContext(), String.valueOf((long)(_errorCode)).concat("\n".concat(_errorMessage)));
			}
		};
		chat_2.addChildEventListener(_chat_2_child_listener);
		
		_listChatU1_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		listChatU1.addChildEventListener(_listChatU1_child_listener);
		
		_listChatU2_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		listChatU2.addChildEventListener(_listChatU2_child_listener);
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				map_pesan.clear();
				c = Calendar.getInstance();
				push_key = chat.push().getKey();
				map_pesan = new HashMap<>();
				map_pesan.put("pesan", pesan_);
				map_pesan.put("tanggal", new SimpleDateFormat("MMM dd, yyyy").format(c.getTime()));
				map_pesan.put("jam", new SimpleDateFormat("HH:mm").format(c.getTime()));
				map_pesan.put("gmt", new SimpleDateFormat("ZZZZ").format(c.getTime()));
				map_pesan.put("reply", "");
				map_pesan.put("reply id", "");
				map_pesan.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				map_pesan.put("push key", push_key);
				chat.child(push_key).updateChildren(map_pesan);
				chat_2.child(push_key).updateChildren(map_pesan);
				map_pesan.put("uid2", uid2);
				listChatU1.child(uid2).updateChildren(map_pesan);
				map_pesan.put("uid2", FirebaseAuth.getInstance().getCurrentUser().getUid());
				listChatU2.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map_pesan);
				edittext2.setText("");
				button2.setAlpha((float)(0.5d));
				button2.setText("send");
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				button2.setAlpha((float)(1));
				button2.setEnabled(true);
				button2.setText("send");
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
		
		_data_user_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		data_user.addChildEventListener(_data_user_child_listener);
		
		_typing_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		typing.addChildEventListener(_typing_child_listener);
		
		_typing_u2_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				try{
					typing_str = _childValue.get("typing").toString();
				}catch(Exception e){
					SketchwareUtil.showMessage(getApplicationContext(), "xyz");
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				try{
					typing_str1 = _childValue.get("typing").toString();
				}catch(Exception e){
					SketchwareUtil.showMessage(getApplicationContext(), "xyz");
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		typing_u2.addChildEventListener(_typing_u2_child_listener);
		
		_last_seen_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		last_seen.addChildEventListener(_last_seen_child_listener);
		
		_last_seen_u2_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				ts_online = _childValue.get("millisecond").toString();
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				ts_online = _childValue.get("millisecond").toString();
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		last_seen_u2.addChildEventListener(_last_seen_u2_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
			b_timer = false;
			_changeActivityFont("font");
			linear5.setVisibility(View.GONE);
			imageview2.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
			imageview3.setColorFilter(0xFF9E9E9E, PorterDuff.Mode.MULTIPLY);
			last_seen_ = false;
			typing.removeEventListener(_typing_child_listener);
			typing_str = "data user/typing/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid());
			typing = _firebase.getReference(typing_str);
			typing.addChildEventListener(_typing_child_listener);
			typing_u2.removeEventListener(_typing_u2_child_listener);
			typing_u2_str = "data user/typing/".concat(getIntent().getStringExtra("uid"));
			typing_u2 = _firebase.getReference(typing_u2_str);
			typing_u2.addChildEventListener(_typing_u2_child_listener);
			last_seen.removeEventListener(_last_seen_child_listener);
			last_seen_str = "data user/last seen/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid());
			last_seen = _firebase.getReference(last_seen_str);
			last_seen.addChildEventListener(_last_seen_child_listener);
			last_seen_u2.removeEventListener(_last_seen_u2_child_listener);
			last_seen_u2_str = "data user/last seen/".concat(getIntent().getStringExtra("uid"));
			last_seen_u2 = _firebase.getReference(last_seen_u2_str);
			last_seen_u2.addChildEventListener(_last_seen_u2_child_listener);
			finish = true;
			online = true;
			tim = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							finish = false;
							online = false;
						}
					});
				}
			};
			_timer.schedule(tim, (int)(600));
			_push_data_online();
			_ToolbarMenu();
			_get_child_key();
			_get_user_info();
			if (!share.getString("user project", "").equals("")) {
				lm_user_project = new Gson().fromJson(share.getString("user project", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			}
			share.edit().putString("list_chat_", "ya").commit();
			edittext2.setMaxHeight(230);
			sound = new SoundPool((int)(2), AudioManager.STREAM_MUSIC, 0);
			sound_receive = sound.load(getApplicationContext(), R.raw.sent, 1);
			sound_sent = sound.load(getApplicationContext(), R.raw.new_message, 1);
			uid2 = getIntent().getStringExtra("uid");
			chat.removeEventListener(_chat_child_listener);
			chat_str = "chat/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("/".concat(getIntent().getStringExtra("uid"))));
			chat = _firebase.getReference(chat_str);
			chat.addChildEventListener(_chat_child_listener);
			chat_2.removeEventListener(_chat_2_child_listener);
			chat_str_2 = "chat/".concat(getIntent().getStringExtra("uid").concat("/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid())));
			chat_2 = _firebase.getReference(chat_str_2);
			chat_2.addChildEventListener(_chat_2_child_listener);
			listChatU1.removeEventListener(_listChatU1_child_listener);
			listchat_u1 = "chat list/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid());
			listChatU1 = _firebase.getReference(listchat_u1);
			listChatU1.addChildEventListener(_listChatU1_child_listener);
			listChatU2.removeEventListener(_listChatU2_child_listener);
			listchat_u2 = "chat list/".concat(uid2);
			listChatU2 = _firebase.getReference(listchat_u2);
			listChatU2.addChildEventListener(_listChatU2_child_listener);
			_saveList(share, ls, false);
			onchildAdded = false;
			get_messages = true;
			_get_message_();
			_RoundAndBorder(button2, "#ffffff", 2, "#607d8b", 50);
			button2.setEnabled(false);
			button2.setAlpha((float)(0.5d));
		}
		else {
			finish();
		}
	}
	
	@Override
	public void onStop() {
		super.onStop();
		get_messages = false;
		share.edit().putString("list_chat_", "").commit();
		finish = true;
		last_seen_ = true;
		onchildAdded = false;
	}
	
	@Override
	public void onResume() {
		super.onResume();
		if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
			get_messages = true;
			share.edit().putString("list_chat_", "ya").commit();
			finish = false;
			last_seen_ = false;
			online = false;
			onchildAdded = true;
			_push_data_online();
			trigger = true;
			b_timer = false;
			_set_typing();
		}
		else {
			finish();
		}
	}
	public void _SortMap(final ArrayList<HashMap<String, Object>> _listMap, final String _key, final boolean _isNumber, final boolean _Ascending) {
		final Object _keyObject = _key;
		Collections.sort(_listMap, new Comparator<HashMap<String,Object>>(){
			public int compare(HashMap<String,Object> _compareMap1, HashMap<String,Object> _compareMap2){
				if (_isNumber) {
					int _count1 = Integer.valueOf(_compareMap1.get(_key).toString());
					int _count2 = Integer.valueOf(_compareMap2.get(_key).toString());
					if (_Ascending) {
						return _count1 < _count2 ? -1 : _count1 < _count2 ? 1 : 0;
					}
					else {
						return _count1 > _count2 ? -1 : _count1 > _count2 ? 1 : 0;
					}
				}
				else {
					if (_Ascending) {
						return (_compareMap1.get(_key).toString()).compareTo(_compareMap2.get(_key).toString());
					}
					else {
						return (_compareMap2.get(_key).toString()).compareTo(_compareMap1.get(_key).toString());
					}
				}
			}});
		///Use true or false blocks if sorting number of listmap
	}
	
	
	public void _hide_date(final double _n, final View _v) {
		_v.setVisibility(View.GONE);
		if ((_n == 0) && (lm_pesan.size() == 1)) {
			_v.setVisibility(View.VISIBLE);
		}
		if (_n == (lm_pesan.size() - 1)) {
			_v.setVisibility(View.VISIBLE);
		}
		if (!(_n == (lm_pesan.size() - 1)) && !(_n == 0)) {
			if (!lm_pesan.get((int)_n).get("uid").toString().equals(lm_pesan.get((int)_n + 1).get("uid").toString())) {
				_v.setVisibility(View.VISIBLE);
			}
		}
	}
	
	
	public void _set_bubble(final View _view, final double _position, final String _uid) {
		besar = 60;
		kecil = 8;
		warna_uid1 = "#607d8b";
		warna_uid_2 = "#ffffff";
		if (_position == 0) {
			if (lm_pesan.size() > 1) {
				if (_uid.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_uid.equals(lm_pesan.get((int)_position + 1).get("uid").toString())) {
						_advancedCorners(_view, warna_uid1, besar, besar, besar, kecil);
					}
					else {
						_advancedCorners(_view, warna_uid1, besar, besar, besar, besar);
					}
					_RoundandShadow(0, 3, warna_uid1, _view);
				}
				else {
					if (_uid.equals(lm_pesan.get((int)_position + 1).get("uid").toString())) {
						_advancedCorners(_view, warna_uid_2, besar, besar, kecil, besar);
					}
					else {
						_advancedCorners(_view, warna_uid_2, besar, besar, besar, besar);
					}
					_RoundandShadow(0, 3, warna_uid_2, _view);
				}
			}
		}
		if (_uid.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
			if ((_position == 0) && (lm_pesan.size() == 1)) {
				_advancedCorners(_view, warna_uid1, besar, besar, besar, besar);
			}
			if ((lm_pesan.size() > 1) && (_position == (lm_pesan.size() - 1))) {
				if (_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid1, besar, kecil, besar, besar);
				}
				if (!_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid1, besar, besar, besar, besar);
				}
			}
			if ((_position > 0) && (_position < (lm_pesan.size() - 1))) {
				if (!_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString()) && !_uid.equals(lm_pesan.get((int)_position + 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid1, besar, besar, besar, besar);
				}
				if (_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString()) && _uid.equals(lm_pesan.get((int)_position + 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid1, besar, kecil, besar, kecil);
				}
				if (!_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString()) && _uid.equals(lm_pesan.get((int)_position + 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid1, besar, besar, besar, kecil);
				}
				if (_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString()) && !_uid.equals(lm_pesan.get((int)_position + 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid1, besar, kecil, besar, besar);
				}
			}
			_RoundandShadow(0, 3, warna_uid1, _view);
		}
		if (!_uid.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
			_RoundandShadow(0, 3, warna_uid_2, _view);
			if ((_position == 0) && (lm_pesan.size() == 1)) {
				_advancedCorners(_view, warna_uid_2, besar, besar, besar, besar);
			}
			if ((lm_pesan.size() > 1) && (_position == (lm_pesan.size() - 1))) {
				if (_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid_2, kecil, besar, besar, besar);
				}
				if (!_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid_2, besar, besar, besar, besar);
				}
			}
			if ((_position > 0) && (_position < (lm_pesan.size() - 1))) {
				if (!_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString()) && !_uid.equals(lm_pesan.get((int)_position + 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid_2, besar, besar, besar, besar);
				}
				if (_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString()) && _uid.equals(lm_pesan.get((int)_position + 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid_2, kecil, besar, kecil, besar);
				}
				if (!_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString()) && _uid.equals(lm_pesan.get((int)_position + 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid_2, besar, besar, kecil, besar);
				}
				if (_uid.equals(lm_pesan.get((int)_position - 1).get("uid").toString()) && !_uid.equals(lm_pesan.get((int)_position + 1).get("uid").toString())) {
					_advancedCorners(_view, warna_uid_2, kecil, besar, besar, besar);
				}
			}
		}
	}
	
	
	public void _advancedCorners(final View _view, final String _color, final double _n1, final double _n2, final double _n3, final double _n4) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		
		gd.setCornerRadii(new float[]{(int)_n1,(int)_n1,(int)_n2,(int)_n2,(int)_n4,(int)_n4,(int)_n3,(int)_n3});
		
		_view.setBackground(gd);
	}
	
	
	public void _get_message_() {
		if (!pesan.getString(uid2, "").equals("")) {
			lm_pesan = new Gson().fromJson(pesan.getString(uid2, ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			_SortMap(lm_pesan, "push key", false, true);
			listview1.setAdapter(new Listview1Adapter(lm_pesan));
			((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			 listview1.setStackFromBottom(true);
		}
		if (!share.getString("map key pesan", "").equals("")) {
			map_key_pesan = new Gson().fromJson(share.getString("map key pesan", ""), new TypeToken<HashMap<String, Object>>(){}.getType());
		}
		button2.setEnabled(false);
		chat.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				lm_listchat_temp = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						lm_listchat_temp.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				get_message = 0;
				for(int _repeat12 = 0; _repeat12 < (int)(lm_listchat_temp.size()); _repeat12++) {
					if (!map_key_pesan.containsKey(lm_listchat_temp.get((int)get_message).get("push key").toString())) {
						map_key_pesan.put(lm_listchat_temp.get((int)get_message).get("push key").toString(), "swd");
						map_get_pesan = lm_listchat_temp.get((int)get_message);
						lm_pesan.add(map_get_pesan);
						chat.child(lm_listchat_temp.get((int)get_message).get("push key").toString()).removeValue();
						share.edit().putString("map key pesan", new Gson().toJson(map_key_pesan)).commit();
						get_message++;
						if (get_message == lm_listchat_temp.size()) {
							get_message = 0;
							pesan.edit().putString(uid2, new Gson().toJson(lm_pesan)).commit();
							share.edit().putString(uid2, lm_pesan.get((int)lm_pesan.size() - 1).get("push key").toString()).commit();
							lm_listchat_temp.clear();
							_SortMap(lm_pesan, "push key", false, true);
							listview1.setAdapter(new Listview1Adapter(lm_pesan));
							((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
							listview1.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL); listview1.setStackFromBottom(true);
							if (lm_pesan.get((int)lm_pesan.size() - 1).get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
								sound_sent = sound.play((int)(1), 1.0f, 1.0f, 1, (int)(0), 1.0f);
							}
							else {
								sound_receive = sound.play((int)(2), 1.0f, 1.0f, 1, (int)(0), 1.0f);
							}
							share.edit().putString("key list chat", lm_pesan.get((int)lm_pesan.size() - 1).get("push key").toString()).commit();
						}
					}
				}
				if (onchildAdded) {
					
				}
				else {
					tim = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									button2.setEnabled(true);
									onchildAdded = true;
								}
							});
						}
					};
					_timer.schedule(tim, (int)(500));
				}
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
	}
	
	
	public void _saveList(final SharedPreferences _getShPref, final ArrayList<String> _getList, final boolean _isSaving) {
		//set SharedPreferences and ListString when you start this block
		if (!_getShPref.getString("length", "").equals("")) {
			if (_isSaving) {
				//saves the list
				length = _getList.size();
				place = length - 1;
				_getShPref.edit().putString("length", String.valueOf((long)(length))).commit();
				for(int _repeat16 = 0; _repeat16 < (int)(length); _repeat16++) {
					_getShPref.edit().putString(String.valueOf((long)(place)), _getList.get((int)(place))).commit();
					place--;
				}
			}
			else {
				//read from SharedPreferences
				length = Double.parseDouble(_getShPref.getString("length", ""));
				place = length - 1;
				for(int _repeat43 = 0; _repeat43 < (int)(length); _repeat43++) {
					_getList.add(_getShPref.getString(String.valueOf((long)(place)), ""));
					place--;
				}
			}
		}
		else {
			
		}
	}
	
	
	public void _RoundAndBorder(final View _view, final String _color1, final double _border, final String _color2, final double _round) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color1));
		gd.setCornerRadius((int) _round);
		gd.setStroke((int) _border, Color.parseColor(_color2));
		_view.setBackground(gd);
	}
	
	
	public void _get_child_key() {
		
	}
	
	
	public void _ToolbarMenu() {
		//toolbar menu
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu){
		
		menu.add("View profile").setShowAsAction(MenuItem.SHOW_AS_ACTION_NEVER);
		return true;
	}
	
	@Override 
	public boolean onOptionsItemSelected(final MenuItem item) {
		switch (item.getTitle().toString()) {
			case "View profile":
			
			i.putExtra("uid", uid2);
			i.setClass(getApplicationContext(), ProfileActivity.class);
			startActivity(i);
			default:
			return super.onOptionsItemSelected(item);
		}
	}
	
	
	public void _set_pesan(final String _project_id, final TextView _pesan, final TextView _judul, final ImageView _img_view, final double _position) {
		if (lm_user_project.size() == 0) {
			SketchwareUtil.showMessage(getApplicationContext(), "null");
		}
		else {
			try{
				get_username = 0;
				_judul.setVisibility(View.VISIBLE);
				for(int _repeat11 = 0; _repeat11 < (int)(lm_user_project.size()); _repeat11++) {
					if (_project_id.equals(lm_user_project.get((int)get_username).get("push key").toString())) {
						Glide.with(getApplicationContext()).load(Uri.parse(lm_user_project.get((int)get_username).get("icon").toString())).into(_img_view);
						if (lm_user_project.get((int)get_username).get("icon").toString().equals("")) {
							_img_view.setImageResource(R.drawable.android);
						}
						_judul.setText(lm_user_project.get((int)get_username).get("judul").toString());
					}
					get_username++;
				}
			}catch(Exception e){
				 
			}
		}
	}
	
	
	public void _get_project(final String _project_id, final double _position) {
		get_username = 0;
		for(int _repeat10 = 0; _repeat10 < (int)(lm_user_project.size()); _repeat10++) {
			if (lm_user_project.get((int)get_username).get("push key").toString().equals(_project_id)) {
				map_user_project = lm_user_project.get((int)get_username);
				i.putExtra("notif", "");
				i.putExtra("data", new Gson().toJson(map_user_project));
				
				startActivity(i);
			}
			get_username++;
		}
	}
	
	
	public void _get_user_info() {
		if (!kontak.getString("kontak", "").equals("")) {
			try{
				lm_users = new Gson().fromJson(kontak.getString("kontak", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			}catch(Exception e){
				SketchwareUtil.showMessage(getApplicationContext(), "1");
			}
		}
		if (!kontak.getString("kontak saya", "").equals("")) {
			try{
				lm_data_user = new Gson().fromJson(kontak.getString("kontak saya", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			}catch(Exception e){
				SketchwareUtil.showMessage(getApplicationContext(), "2");
			}
		}
		if (!kontak.getString("uid", "").equals("")) {
			try{
				nap_user_id = new Gson().fromJson(kontak.getString("uid", ""), new TypeToken<HashMap<String, Object>>(){}.getType());
			}catch(Exception e){
				SketchwareUtil.showMessage(getApplicationContext(), "3");
			}
		}
		setTitle(getIntent().getStringExtra("uid"));
		if (kontak.getString("kontak", "").contains(getIntent().getStringExtra("uid"))) {
			get_username = 0;
			for(int _repeat127 = 0; _repeat127 < (int)(lm_users.size()); _repeat127++) {
				if (lm_users.get((int)get_username).get("uid").toString().equals(getIntent().getStringExtra("uid"))) {
					username_ = lm_users.get((int)get_username).get("username").toString();
					setTitle(lm_users.get((int)get_username).get("username").toString());
				}
				get_username++;
			}
		}
		else {
			data_user.removeEventListener(_data_user_child_listener);
			data_user_str = "data user/uid/".concat(getIntent().getStringExtra("uid"));
			data_user = _firebase.getReference(data_user_str);
			data_user.addChildEventListener(_data_user_child_listener);
			data_user.addListenerForSingleValueEvent(new ValueEventListener() {
				@Override
				public void onDataChange(DataSnapshot _dataSnapshot) {
					lm_data_user_temp = new ArrayList<>();
					try {
						GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
						for (DataSnapshot _data : _dataSnapshot.getChildren()) {
							HashMap<String, Object> _map = _data.getValue(_ind);
							lm_data_user_temp.add(_map);
						}
					}
					catch (Exception _e) {
						_e.printStackTrace();
					}
					if (lm_data_user_temp.size() > 0) {
						map_add_user = lm_data_user_temp.get((int)0);
						lm_data_user.add(map_add_user);
						lm_users.add(map_add_user);
						kontak.edit().putString("kontak saya", new Gson().toJson(lm_data_user)).commit();
						kontak.edit().putString("kontak", new Gson().toJson(lm_users)).commit();
						kontak.edit().putString("uid", new Gson().toJson(nap_user_id)).commit();
						get_username = 0;
						for(int _repeat106 = 0; _repeat106 < (int)(lm_data_user.size()); _repeat106++) {
							if (lm_data_user.get((int)get_username).get("uid").toString().equals(getIntent().getStringExtra("uid"))) {
								username_ = lm_data_user.get((int)get_username).get("username").toString();
								setTitle(lm_data_user.get((int)get_username).get("username").toString());
							}
							get_username++;
						}
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "user doesn't use the latest version of sketch cloud");
					}
				}
				@Override
				public void onCancelled(DatabaseError _databaseError) {
				}
			});
		}
	}
	
	
	public void _set_online() {
		if (last_seen_) {
			
		}
		else {
			if (typing_) {
				
			}
			else {
				if (ts_online.equals("") || ts_online2.equals("")) {
					ts_online2 = ts_online;
				}
				else {
					if (ts_online.equals(ts_online2)) {
						try{
							cal_last_seen.setTimeInMillis((long)(Double.parseDouble(ts_online)));
						}catch(Exception e){
							SketchwareUtil.showMessage(getApplicationContext(), " vv");
						}
						last_seen__ = new SimpleDateFormat("MMM dd, yyyy • HH.mm").format(cal_last_seen.getTime());
						getSupportActionBar().setSubtitle(last_seen__);
					}
					else {
						getSupportActionBar().setSubtitle("Online");
					}
					ts_online2 = ts_online;
				}
			}
		}
	}
	
	
	public void _push_data_online() {
		t2 = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (last_seen_) {
							t2.cancel();
						}
						else {
							c = Calendar.getInstance();
							map_last_seen.put("jam", new SimpleDateFormat("HH.mm").format(c.getTime()));
							map_last_seen.put("tanggal", new SimpleDateFormat("dd/MM/yyyy").format(c.getTime()));
							map_last_seen.put("millisecond", String.valueOf((long)(c.getTimeInMillis())));
							map_last_seen.put("gmt", new SimpleDateFormat("ZZZZ").format(c.getTime()));
							last_seen.child("ims last seen").updateChildren(map_last_seen);
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(t2, (int)(0), (int)(250));
	}
	
	
	public void _RoundandShadow(final double _Radius, final double _Elevation, final String _color, final View _v) {
		float e = (float) _Elevation;
		_v.setElevation(e);
	}
	
	
	public void _RelativeSize_Text(final TextView _textview, final double _start, final double _end, final double _size) {
		Spannable spannable = SpannableStringBuilder.valueOf(_textview.getText());
		spannable.setSpan(new android.text.style.RelativeSizeSpan((int)(_size)), (int)(_start), (int)(_end), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
		_textview.setText(spannable);
	}
	
	
	public void _setTextViewSize(final TextView _textview, final double _size) {
		_textview.setTextSize((float)_size);
	}
	
	
	public void _setTextSize(final String _pesan, final String _jam, final TextView _tview) {
		pesan_jam = _pesan.concat(" ".concat(_jam));
		panjang_pesan = _pesan.length() + 1;
		panjang_jam = pesan_jam.length();
		_tview.setText(pesan_jam);
		_setTextViewSize(_tview, 5);
		_RelativeSize_Text(_tview, 0, panjang_pesan, 3);
		_RelativeSize_Text(_tview, panjang_pesan, pesan_jam.length(), 2);
	}
	
	
	public void _set_vis(final TextView _tv, final double _poss, final View _view, final ArrayList<HashMap<String, Object>> _lm_vis) {
		_view.setVisibility(View.GONE);
		_real_round_shadow(50, 5, "#ffffff", _view);
		c = Calendar.getInstance();
		tss.setTimeInMillis((long)(Double.parseDouble(_lm_vis.get((int)_poss).get("time stamp").toString())));
		if (_poss == 0) {
			if (new SimpleDateFormat("MMM dd, yyyy").format(c.getTime()).equals(new SimpleDateFormat("MMM dd, yyyy").format(tss.getTime()))) {
				_view.setVisibility(View.GONE);
			}
			else {
				_tv.setText(new SimpleDateFormat("MMM dd, yyyy").format(tss.getTime()));
				_view.setVisibility(View.VISIBLE);
			}
		}
		if (_lm_vis.size() > 1) {
			if (!(_poss == 0)) {
				try {
					ts_1.setTimeInMillis((long)(Double.parseDouble(_lm_vis.get((int)_poss - 1).get("time stamp").toString())));
					if (new SimpleDateFormat("MMM dd, yyyy").format(tss.getTime()).equals(new SimpleDateFormat("MMM dd, yyyy").format(ts_1.getTime()))) {
						_view.setVisibility(View.GONE);
					}
					else {
						_tv.setText(new SimpleDateFormat("MMM dd, yyyy").format(tss.getTime()));
						_view.setVisibility(View.VISIBLE);
					}
				}
				catch (Exception e)
				
				{
					error = e.toString();
					SketchwareUtil.showMessage(getApplicationContext(), error);
				}
			}
		}
	}
	
	
	public void _real_round_shadow(final double _Radius, final double _Elevation, final String _color, final View _v) {
		float r = (float) _Radius;
		float e = (float) _Elevation;
		_v.setElevation(e);
		android.graphics.drawable.GradientDrawable s=new android.graphics.drawable.GradientDrawable();
		s.setColor(Color.parseColor(_color));
		s.setCornerRadius(r);
		_v.setBackground(s);
	}
	
	
	public void _popup_menu(final View _view, final double _position) {
		//change the activity if mainactivity is not yours
		
		PopupMenu popup = new PopupMenu(PesanActivity.this, _view);
		Menu menu = popup.getMenu();
		//add menu or change the name
		// you will change the name in the different case or add other cases in the blocks below
		
		menu.add("Copy");
		menu.add("Reply");
		popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener(){
			@Override
			public boolean onMenuItemClick(MenuItem item){
				switch (item.getTitle().toString()){
					case "Reply":
					break;
					case "Copy":
					SketchwareUtil.showMessage(getApplicationContext(), "Copied to clipboard");
					((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", lm_pesan.get((int)_position).get("pesan").toString()));
					break;}
				return true;
			}
		});
		popup.show();
	}
	
	
	public void _long_click(final View _view, final double _position) {
		//add this block to onCreate 
		_view.setOnLongClickListener(new View.OnLongClickListener() {@Override public boolean onLongClick(View v){
				_popup_menu(_view, _position);
				 return true;}});
	}
	
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		int style = 0;
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					
					if (((TextView) v).getTypeface().getStyle()==Typeface.NORMAL) {
						
						style = 0;
						
					}else{
						
						if (((TextView) v).getTypeface().getStyle()==Typeface.BOLD) {
							
							style = 1;
							
						}else{
							
							if (((TextView) v).getTypeface().getStyle()==Typeface.ITALIC) {
								
								style = 2;
								
							}else{
								
								if (((TextView) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
									
									style = 3;
									
								}}}}
					
					((TextView) v).setTypeface(typeace, (style));
					
				}
				else {
					if ((v instanceof EditText )) {
						if (((EditText) v).getTypeface().getStyle()==Typeface.NORMAL) {
							
							style = 0;
							
						}else{
							
							if (((EditText) v).getTypeface().getStyle()==Typeface.BOLD) {
								
								style = 1;
								
							}else{
								
								if (((EditText) v).getTypeface().getStyle()==Typeface.ITALIC) {
									
									style = 2;
									
								}else{
									
									if (((EditText) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
										
										style = 3;
										
									}}}}
						
						((EditText) v).setTypeface(typeace, (style));
					}
					else {
						if ((v instanceof RadioButton )) {
							if (((RadioButton) v).getTypeface().getStyle()==Typeface.NORMAL) {
								
								style = 0;
								
							}else{
								
								if (((RadioButton) v).getTypeface().getStyle()==Typeface.BOLD) {
									
									style = 1;
									
								}else{
									
									if (((RadioButton) v).getTypeface().getStyle()==Typeface.ITALIC) {
										
										style = 2;
										
									}else{
										
										if (((RadioButton) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
											
											style = 3;
											
										}}}}
							
							((RadioButton) v).setTypeface(typeace, (style));
						}
						else {
							if ((v instanceof CheckBox )) {
								if (((CheckBox) v).getTypeface().getStyle()==Typeface.NORMAL) {
									
									style = 0;
									
								}else{
									
									if (((CheckBox) v).getTypeface().getStyle()==Typeface.BOLD) {
										
										style = 1;
										
									}else{
										
										if (((CheckBox) v).getTypeface().getStyle()==Typeface.ITALIC) {
											
											style = 2;
											
										}else{
											
											if (((CheckBox) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
												
												style = 3;
												
											}}}}
								
								((CheckBox) v).setTypeface(typeace, (style));
							}
							else {
								if ((v instanceof Switch )) {
									if (((Switch) v).getTypeface().getStyle()==Typeface.NORMAL) {
										
										style = 0;
										
									}else{
										
										if (((Switch) v).getTypeface().getStyle()==Typeface.BOLD) {
											
											style = 1;
											
										}else{
											
											if (((Switch) v).getTypeface().getStyle()==Typeface.ITALIC) {
												
												style = 2;
												
											}else{
												
												if (((Switch) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
													
													style = 3;
													
												}}}}
									
									((Switch) v).setTypeface(typeace, (style));
								}
								else {
									if ((v instanceof Button)) {
										if (((Button) v).getTypeface().getStyle()==Typeface.NORMAL) {
											
											style = 0;
											
										}else{
											
											if (((Button) v).getTypeface().getStyle()==Typeface.BOLD) {
												
												style = 1;
												
											}else{
												
												if (((Button) v).getTypeface().getStyle()==Typeface.ITALIC) {
													
													style = 2;
													
												}else{
													
													if (((Button) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
														
														style = 3;
														
													}}}}
										
										((Button) v).setTypeface(typeace, (style));
									}
								}
							}
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	public void _set_typing() {
		timer_typing = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (last_seen_) {
							timer_typing.cancel();
						}
						else {
							if (typing_str1.equals(typing_str2)) {
								typing_ = false;
								_set_online();
							}
							else {
								try{
									set_Subtittle = "typing...";
									getSupportActionBar().setSubtitle(set_Subtittle);
									
								}catch(Exception e){
									 
								}
								typing_str2 = typing_str1;
								typing_ = true;
							}
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(timer_typing, (int)(0), (int)(300));
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.pesanf, null);
			}
			
			final LinearLayout blocked_linear_info = _view.findViewById(R.id.blocked_linear_info);
			final LinearLayout linear7 = _view.findViewById(R.id.linear7);
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear_tgl = _view.findViewById(R.id.linear_tgl);
			final TextView blocked_text_info = _view.findViewById(R.id.blocked_text_info);
			final TextView textview5 = _view.findViewById(R.id.textview5);
			final LinearLayout linear_pesan = _view.findViewById(R.id.linear_pesan);
			final LinearLayout dasar_reply_0 = _view.findViewById(R.id.dasar_reply_0);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear_garis = _view.findViewById(R.id.linear_garis);
			final LinearLayout dasar_reply = _view.findViewById(R.id.dasar_reply);
			final TextView username_rep = _view.findViewById(R.id.username_rep);
			final TextView pesan_rep = _view.findViewById(R.id.pesan_rep);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final TextView textview6 = _view.findViewById(R.id.textview6);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final LinearLayout linear8 = _view.findViewById(R.id.linear8);
			final com.jgabrielfreitas.core.BlurImageView image = _view.findViewById(R.id.image);
			final ImageView sticker = _view.findViewById(R.id.sticker);
			final TextView tanggal = _view.findViewById(R.id.tanggal);
			
			textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
			username_rep.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
			pesan_rep.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
			textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
			
			
			tanggal.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
			_long_click(linear1, _position);
			dasar_reply_0.setVisibility(View.GONE);
			cardview1.setVisibility(View.GONE);
			sticker.setVisibility(View.GONE);
			textview6.setVisibility(View.GONE);
			blocked_linear_info.setVisibility(View.GONE);
			linear6.setVisibility(View.GONE);
			c = Calendar.getInstance();
			try {
				if (lm_pesan.get((int)_position).containsKey("reply uidxh")) {
					if (!lm_pesan.get((int)_position).get("reply uid").toString().equals("")) {
						_advancedCorners(linear_garis, "#cfd8dc", 8, 8, 8, 8);
						dasar_reply_0.setVisibility(View.VISIBLE);
						_RoundAndBorder(dasar_reply, "#eeeeee", 1, "#e0e0e0", 8);
						pesan_rep.setText(map_key_pesan.get(lm_pesan.get((int)_position).get("reply id").toString()).toString());
						if (lm_pesan.get((int)_position).get("reply uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
							username_rep.setText(share.getString("username", ""));
						}
						else {
							username_rep.setText(username_);
						}
					}
				}
				if (lm_pesan.get((int)_position).containsKey("pesan")) {
					if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(lm_pesan.get((int)_position).get("uid").toString())) {
						ts.setTimeInMillis((long)(Double.parseDouble(lm_pesan.get((int)_position).get("time stamp").toString())));
						if (map_sent_read.containsKey(lm_pesan.get((int)_position).get("push key").toString())) {
							tanggal.setText("");
							_setTextSize(lm_pesan.get((int)_position).get("pesan").toString(), "   sent".concat(" • ".concat(new SimpleDateFormat("HH:mm").format(ts.getTime()))), textview2);
						}
						else {
							tanggal.setText("");
							_setTextSize(lm_pesan.get((int)_position).get("pesan").toString(), "   read".concat(" • ".concat(new SimpleDateFormat("HH:mm").format(ts.getTime()))), textview2);
						}
					}
					else {
						ts.setTimeInMillis((long)(Double.parseDouble(lm_pesan.get((int)_position).get("time stamp").toString())));
						tanggal.setText("");
						_setTextSize(lm_pesan.get((int)_position).get("pesan").toString(), "   ".concat(new SimpleDateFormat("HH:mm").format(ts.getTime())), textview2);
					}
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "tidak ada key pesan");
				}
			}
			
			catch (Exception e)
			{
				error = e.toString();
				SketchwareUtil.showMessage(getApplicationContext(), error);
			}
			if (lm_pesan.get((int)_position).containsKey("uid")) {
				if (lm_pesan.get((int)_position).get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					linear1.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
					linear_tgl.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
					linear1.setPadding(120,0,8,0);
					
					textview2.setTextColor(Color.parseColor("#ffffff"));
					
					textview3.setTextColor(Color.parseColor("#ffffff"));
					
				}
				else {
					linear1.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);
					linear_tgl.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);
					
					textview2.setTextColor(Color.parseColor("#000000"));
					
					textview3.setTextColor(Color.parseColor("#000000"));
					
					
					
					linear1.setPadding(8,0,120,0);
				}
				_set_vis(textview5, _position, linear7, lm_pesan);
				_set_bubble(linear_pesan, _position, lm_pesan.get((int)_position).get("uid").toString());
			}
			else {
				chat.child(lm_pesan.get((int)_position).get("push key").toString()).removeValue();
			}
			if (!FirebaseAuth.getInstance().getCurrentUser().getUid().equals(lm_pesan.get((int)_position).get("uid").toString())) {
				
				textview2.setTextColor(Color.parseColor("#000000"));
				
				textview3.setTextColor(Color.parseColor("#000000"));
				
				
				
			}
			linear2.setVisibility(View.GONE);
			textview2.setPadding(12,4,8,4);
			
			if (lm_pesan.get((int)_position).containsKey("project id")) {
				_set_pesan(lm_pesan.get((int)_position).get("project id").toString(), textview2, textview3, imageview1, _position);
				textview2.setPadding(8,0,8,4);
				
				linear2.setVisibility(View.VISIBLE);
			}
			textview3.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					_get_project(lm_pesan.get((int)_position).get("project id").toString(), _position);
				}
			});
			_hide_date(_position, linear_tgl);
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}