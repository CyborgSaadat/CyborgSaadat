package com.scloud.chat;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.jgabrielfreitas.core.*;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class ListChatActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private FloatingActionButton _fab;
	private DrawerLayout _drawer;
	private String list_chat_str = "";
	private double get_user = 0;
	private String chat_str = "";
	private double repeat = 0;
	private HashMap<String, Object> map_uid_user = new HashMap<>();
	private HashMap<String, Object> map_get_listchat = new HashMap<>();
	private double del = 0;
	private boolean list_chat_ = false;
	private HashMap<String, Object> mute = new HashMap<>();
	private HashMap<String, Object> map_user_info = new HashMap<>();
	private HashMap<String, Object> map_user_id = new HashMap<>();
	private boolean last_seen_ = false;
	private HashMap<String, Object> map_last_seen = new HashMap<>();
	private String data_user_str = "";
	private String fontName = "";
	private String typeace = "";
	
	private ArrayList<HashMap<String, Object>> lm_list_chat = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_data_user = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_listchat_temp = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_temp = new ArrayList<>();
	
	private LinearLayout linear12;
	private TextView textview2;
	private ListView listview1;
	private LinearLayout linear1;
	private TextView textview3;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private ImageView imageview1;
	private LinearLayout linear5;
	private TextView pesan_global;
	private TextView username;
	private TextView tanggal;
	private TextView textview1;
	private LinearLayout _drawer_linear1;
	private LinearLayout _drawer_linear5;
	private LinearLayout _drawer_linear_project;
	private LinearLayout _drawer_linear3;
	private LinearLayout _drawer_linear_aboutapp;
	private LinearLayout _drawer_linear9;
	private LinearLayout _drawer_linear6;
	private TextView _drawer_textview1;
	private TextView _drawer_textview2;
	private CircleImageView _drawer_circleimageview1;
	private ImageView _drawer_imageview1;
	private TextView _drawer_textview3;
	private ImageView _drawer_imageview3;
	private TextView _drawer_textview5;
	
	private DatabaseReference list_chat = _firebase.getReference(""+list_chat_str+"");
	private ChildEventListener _list_chat_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private Intent i = new Intent();
	private SharedPreferences data_user_spf;
	private SharedPreferences share;
	private DatabaseReference chatU1 = _firebase.getReference(""+chat_str+"");
	private ChildEventListener _chatU1_child_listener;
	private AlertDialog.Builder d;
	private SharedPreferences pesan;
	private AlertDialog.Builder d1;
	private SharedPreferences kontak;
	private DatabaseReference data_user = _firebase.getReference(""+data_user_str+"");
	private ChildEventListener _data_user_child_listener;
	private TimerTask t2;
	private Calendar c = Calendar.getInstance();
	private DatabaseReference chat_global = _firebase.getReference("chat global/pesan terbaru/");
	private ChildEventListener _chat_global_child_listener;
	private Calendar ts = Calendar.getInstance();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.list_chat);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_fab = findViewById(R.id._fab);
		
		_drawer = findViewById(R.id._drawer);
		ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(ListChatActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = findViewById(R.id._nav_view);
		
		linear12 = findViewById(R.id.linear12);
		textview2 = findViewById(R.id.textview2);
		listview1 = findViewById(R.id.listview1);
		linear1 = findViewById(R.id.linear1);
		textview3 = findViewById(R.id.textview3);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		imageview1 = findViewById(R.id.imageview1);
		linear5 = findViewById(R.id.linear5);
		pesan_global = findViewById(R.id.pesan_global);
		username = findViewById(R.id.username);
		tanggal = findViewById(R.id.tanggal);
		textview1 = findViewById(R.id.textview1);
		_drawer_linear1 = _nav_view.findViewById(R.id.linear1);
		_drawer_linear5 = _nav_view.findViewById(R.id.linear5);
		_drawer_linear_project = _nav_view.findViewById(R.id.linear_project);
		_drawer_linear3 = _nav_view.findViewById(R.id.linear3);
		_drawer_linear_aboutapp = _nav_view.findViewById(R.id.linear_aboutapp);
		_drawer_linear9 = _nav_view.findViewById(R.id.linear9);
		_drawer_linear6 = _nav_view.findViewById(R.id.linear6);
		_drawer_textview1 = _nav_view.findViewById(R.id.textview1);
		_drawer_textview2 = _nav_view.findViewById(R.id.textview2);
		_drawer_circleimageview1 = _nav_view.findViewById(R.id.circleimageview1);
		_drawer_imageview1 = _nav_view.findViewById(R.id.imageview1);
		_drawer_textview3 = _nav_view.findViewById(R.id.textview3);
		_drawer_imageview3 = _nav_view.findViewById(R.id.imageview3);
		_drawer_textview5 = _nav_view.findViewById(R.id.textview5);
		auth = FirebaseAuth.getInstance();
		data_user_spf = getSharedPreferences("data user", Activity.MODE_PRIVATE);
		share = getSharedPreferences("share", Activity.MODE_PRIVATE);
		d = new AlertDialog.Builder(this);
		pesan = getSharedPreferences("pesan", Activity.MODE_PRIVATE);
		d1 = new AlertDialog.Builder(this);
		kontak = getSharedPreferences("kontak", Activity.MODE_PRIVATE);
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				i.putExtra("uid", lm_list_chat.get((int)_position).get("uid2").toString());
				i.setClass(getApplicationContext(), PesanActivity.class);
				startActivity(i);
			}
		});
		
		listview1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				d.setMessage("Choose your action to this conversation");
				d.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						d1.setMessage("Delete this conversation?");
						d1.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface _dialog, int _which) {
								chatU1.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("/".concat(lm_list_chat.get((int)_position).get("uid2").toString()))).removeValue();
								list_chat.child(lm_list_chat.get((int)_position).get("uid2").toString()).removeValue();
								pesan.edit().putString(lm_list_chat.get((int)_position).get("uid2").toString(), "").commit();
								map_uid_user.remove(lm_list_chat.get((int)_position).get("uid2").toString());
								lm_list_chat.remove((int)(_position));
								share.edit().putString("list chat", new Gson().toJson(lm_list_chat)).commit();
								share.edit().putString("uid list chat", new Gson().toJson(map_uid_user)).commit();
								_SortMap(lm_list_chat, "push key", false, false);
								listview1.setAdapter(new Listview1Adapter(lm_list_chat));
								((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
							}
						});
						d1.create().show();
					}
				});
				if (mute.containsKey(lm_list_chat.get((int)_position).get("uid2").toString())) {
					d.setNegativeButton("Unmute", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							mute.remove(lm_list_chat.get((int)_position).get("uid2").toString());
							share.edit().putString("mute", new Gson().toJson(mute)).commit();
							_SortMap(lm_list_chat, "push key", false, false);
							listview1.setAdapter(new Listview1Adapter(lm_list_chat));
							((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
						}
					});
				}
				else {
					d.setNegativeButton("Mute", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							mute.put(lm_list_chat.get((int)_position).get("uid2").toString(), "true");
							share.edit().putString("mute", new Gson().toJson(mute)).commit();
							_SortMap(lm_list_chat, "push key", false, false);
							listview1.setAdapter(new Listview1Adapter(lm_list_chat));
							((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
						}
					});
				}
				d.create().show();
				return true;
			}
		});
		
		linear2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), GlobalChatActivity.class);
				startActivity(i);
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), PenggunaActivity.class);
				startActivity(i);
			}
		});
		
		_list_chat_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				_get_list_chat();
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				_get_list_chat();
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		list_chat.addChildEventListener(_list_chat_child_listener);
		
		_chatU1_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		chatU1.addChildEventListener(_chatU1_child_listener);
		
		_data_user_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		data_user.addChildEventListener(_data_user_child_listener);
		
		_chat_global_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				c = Calendar.getInstance();
				username.setText(_childValue.get("username").toString());
				pesan_global.setText(_childValue.get("pesan").toString());
				ts.setTimeInMillis((long)(Double.parseDouble(_childValue.get("time stamp").toString())));
				if (new SimpleDateFormat("MM dd, yyyy").format(ts.getTime()).equals(new SimpleDateFormat("MMM dd, yyyy").format(c.getTime()))) {
					tanggal.setText(new SimpleDateFormat("HH.mm").format(ts.getTime()));
				}
				else {
					tanggal.setText(new SimpleDateFormat("MMM dd, yyyy").format(ts.getTime()));
				}
				if (_childValue.containsKey("id stiker")) {
					if (!_childValue.get("id stiker").toString().equals("")) {
						pesan_global.setTypeface(null, Typeface.ITALIC);
						pesan_global.setText("sticker");
					}
					else {
						pesan_global.setTypeface(null, Typeface.NORMAL);
					}
				}
				else {
					pesan_global.setTypeface(null, Typeface.NORMAL);
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				c = Calendar.getInstance();
				username.setText(_childValue.get("username").toString());
				pesan_global.setText(_childValue.get("pesan").toString());
				ts.setTimeInMillis((long)(Double.parseDouble(_childValue.get("time stamp").toString())));
				tanggal.setText(new SimpleDateFormat("MM dd, yyyy").format(ts.getTime()));
				if (new SimpleDateFormat("MM dd, yyyy").format(ts.getTime()).equals(new SimpleDateFormat("MMM dd, yyyy").format(ts.getTime()))) {
					tanggal.setText(new SimpleDateFormat("HH.mm").format(ts.getTime()));
				}
				else {
					tanggal.setText(new SimpleDateFormat("MMM dd, yyyy").format(ts.getTime()));
				}
				if (_childValue.containsKey("id stiker")) {
					if (!_childValue.get("id stiker").toString().equals("")) {
						pesan_global.setTypeface(null, Typeface.ITALIC);
						pesan_global.setText("sticker");
					}
					else {
						pesan_global.setTypeface(null, Typeface.NORMAL);
					}
				}
				else {
					pesan_global.setTypeface(null, Typeface.NORMAL);
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		chat_global.addChildEventListener(_chat_global_child_listener);
		
		_drawer_linear_project.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		_drawer_linear_aboutapp.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		_drawer_linear9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.putExtra("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				i.setClass(getApplicationContext(), ProfileActivity.class);
				startActivity(i);
				_drawer.closeDrawer(GravityCompat.START);
			}
		});
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
			_changeActivityFont("font");
			imageview1.setColorFilter(0xFF757575, PorterDuff.Mode.MULTIPLY);
			_circleRipple("#cfd8dc", linear2);
			_RoundandShadow(0, 4, "#ffffff", linear12);
			last_seen_ = false;
			setTitle("Message");
			data_user.removeEventListener(_data_user_child_listener);
			data_user_str = "data user/last seen/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid());
			data_user = _firebase.getReference(data_user_str);
			data_user.addChildEventListener(_data_user_child_listener);
			list_chat.removeEventListener(_list_chat_child_listener);
			list_chat_str = "chat list/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid());
			list_chat = _firebase.getReference(list_chat_str);
			list_chat.addChildEventListener(_list_chat_child_listener);
			chatU1.removeEventListener(_chatU1_child_listener);
			chat_str = "chat";
			chatU1 = _firebase.getReference(chat_str);
			chatU1.addChildEventListener(_chatU1_child_listener);
			if (!kontak.getString("kontak", "").equals("")) {
				lm_data_user = new Gson().fromJson(kontak.getString("kontak", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			}
			if (!share.getString("uid list chat", "").equals("")) {
				map_uid_user = new Gson().fromJson(share.getString("uid list chat", ""), new TypeToken<HashMap<String, Object>>(){}.getType());
			}
			list_chat_ = true;
			share.edit().putString("list_chat_", "ya").commit();
			_get_list_chat();
			if (!share.getString("mute", "").equals("")) {
				mute = new Gson().fromJson(share.getString("mute", ""), new TypeToken<HashMap<String, Object>>(){}.getType());
			}
			if (!kontak.getString("uid", "").equals("")) {
				map_user_id = new Gson().fromJson(kontak.getString("uid", ""), new TypeToken<HashMap<String, Object>>(){}.getType());
			}
			data_user.removeEventListener(_data_user_child_listener);
			data_user_str = "data user/uid/".concat(FirebaseAuth.getInstance().getCurrentUser().getUid());
			data_user = _firebase.getReference(data_user_str);
			data_user.addChildEventListener(_data_user_child_listener);
			data_user.addListenerForSingleValueEvent(new ValueEventListener() {
				@Override
				public void onDataChange(DataSnapshot _dataSnapshot) {
					lm_temp = new ArrayList<>();
					try {
						GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
						for (DataSnapshot _data : _dataSnapshot.getChildren()) {
							HashMap<String, Object> _map = _data.getValue(_ind);
							lm_temp.add(_map);
						}
					}
					catch (Exception _e) {
						_e.printStackTrace();
					}
					if (lm_temp.size() > 0) {
						share.edit().putString("username", lm_temp.get((int)0).get("username").toString()).commit();
						Glide.with(getApplicationContext()).load(Uri.parse("https://firebasestorage.googleapis.com/v0/b/kasir-65337.appspot.com/o/data%2F".concat(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("%2Fpic%2Fpic.png?alt=media")))).into(_drawer_circleimageview1);
						_drawer_textview1.setText(lm_temp.get((int)0).get("username").toString());
						_drawer_textview2.setText(FirebaseAuth.getInstance().getCurrentUser().getEmail());
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "User data not found");
					}
				}
				@Override
				public void onCancelled(DatabaseError _databaseError) {
				}
			});
		}
		else {
			finish();
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
			if (!kontak.getString("kontak", "").equals("")) {
				lm_data_user = new Gson().fromJson(kontak.getString("kontak", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			}
			list_chat_ = true;
			share.edit().putString("list_chat_", "ya").commit();
			_get_list_chat();
			last_seen_ = false;
			_push_data_online();
		}
		else {
			finish();
		}
	}
	
	@Override
	public void onDestroy() {
		super.onDestroy();
		share.edit().putString("list_chat_", "").commit();
		list_chat_ = false;
	}
	
	@Override
	public void onStop() {
		super.onStop();
		share.edit().putString("list_chat_", "").commit();
		list_chat_ = false;
		last_seen_ = true;
	}
	
	@Override
	public void onBackPressed() {
		if (_drawer.isDrawerOpen(GravityCompat.START)) {
			_drawer.closeDrawer(GravityCompat.START);
		} else {
			super.onBackPressed();
		}
	}
	public void _SortMap(final ArrayList<HashMap<String, Object>> _listMap, final String _key, final boolean _isNumber, final boolean _Ascending) {
		final Object _keyObject = _key;
		Collections.sort(_listMap, new Comparator<HashMap<String,Object>>(){
			public int compare(HashMap<String,Object> _compareMap1, HashMap<String,Object> _compareMap2){
				if (_isNumber) {
					int _count1 = Integer.valueOf(_compareMap1.get(_key).toString());
					int _count2 = Integer.valueOf(_compareMap2.get(_key).toString());
					if (_Ascending) {
						return _count1 < _count2 ? -1 : _count1 < _count2 ? 1 : 0;
					}
					else {
						return _count1 > _count2 ? -1 : _count1 > _count2 ? 1 : 0;
					}
				}
				else {
					if (_Ascending) {
						return (_compareMap1.get(_key).toString()).compareTo(_compareMap2.get(_key).toString());
					}
					else {
						return (_compareMap2.get(_key).toString()).compareTo(_compareMap1.get(_key).toString());
					}
				}
			}});
		///Use true or false blocks if sorting number of listmap
	}
	
	
	public void _curcle_igm_url(final String _url, final ImageView _img_view) {
		
		
	}
	
	
	public void _RoundandShadow(final double _Radius, final double _Elevation, final String _color, final View _v) {
		float r = (float) _Radius;
		float e = (float) _Elevation;
		_v.setElevation(e);
		android.graphics.drawable.GradientDrawable s=new android.graphics.drawable.GradientDrawable();
		s.setColor(Color.parseColor(_color));
		s.setCornerRadius(r);
		_v.setBackground(s);
	}
	
	
	public void _get_list_chat() {
		listview1.setVisibility(View.GONE);
		linear1.setVisibility(View.VISIBLE);
		if (!share.getString("list chat", "").equals("")) {
			lm_list_chat = new Gson().fromJson(share.getString("list chat", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			_SortMap(lm_list_chat, "push key", false, false);
			listview1.setAdapter(new Listview1Adapter(lm_list_chat));
			((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
			listview1.setVisibility(View.VISIBLE);
			linear1.setVisibility(View.GONE);
		}
		if (share.getString("list_chat_", "").equals("ya")) {
			list_chat.addListenerForSingleValueEvent(new ValueEventListener() {
				@Override
				public void onDataChange(DataSnapshot _dataSnapshot) {
					lm_listchat_temp = new ArrayList<>();
					try {
						GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
						for (DataSnapshot _data : _dataSnapshot.getChildren()) {
							HashMap<String, Object> _map = _data.getValue(_ind);
							lm_listchat_temp.add(_map);
						}
					}
					catch (Exception _e) {
						_e.printStackTrace();
					}
					if (lm_listchat_temp.size() == 0) {
						
					}
					else {
						listview1.setVisibility(View.VISIBLE);
						linear1.setVisibility(View.GONE);
						repeat = 0;
						for(int _repeat29 = 0; _repeat29 < (int)(lm_listchat_temp.size()); _repeat29++) {
							if (map_uid_user.containsKey(lm_listchat_temp.get((int)repeat).get("uid2").toString())) {
								del = 0;
								for(int _repeat40 = 0; _repeat40 < (int)(lm_list_chat.size()); _repeat40++) {
									if (lm_list_chat.get((int)del).get("uid2").toString().equals(lm_listchat_temp.get((int)repeat).get("uid2").toString())) {
										lm_list_chat.remove((int)(del));
										map_get_listchat = lm_listchat_temp.get((int)repeat);
										lm_list_chat.add(map_get_listchat);
										map_uid_user.put(lm_listchat_temp.get((int)repeat).get("uid2").toString(), "true");
										list_chat.child(lm_listchat_temp.get((int)repeat).get("uid2").toString()).removeValue();
										share.edit().putString("list chat", new Gson().toJson(lm_list_chat)).commit();
										share.edit().putString("uid list chat", new Gson().toJson(map_uid_user)).commit();
										_SortMap(lm_list_chat, "push key", false, false);
										listview1.setAdapter(new Listview1Adapter(lm_list_chat));
										((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
									}
									del++;
								}
							}
							else {
								map_get_listchat = lm_listchat_temp.get((int)repeat);
								lm_list_chat.add(map_get_listchat);
								map_uid_user.put(lm_listchat_temp.get((int)repeat).get("uid2").toString(), "true");
								share.edit().putString("list chat", new Gson().toJson(lm_list_chat)).commit();
								share.edit().putString("uid list chat", new Gson().toJson(map_uid_user)).commit();
								_SortMap(lm_list_chat, "push key", false, false);
								listview1.setAdapter(new Listview1Adapter(lm_list_chat));
								((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
								list_chat.child(lm_listchat_temp.get((int)repeat).get("uid2").toString()).removeValue();
							}
							repeat++;
						}
					}
					if (!(lm_list_chat.size() == 0)) {
						share.edit().putString("key list chat", lm_list_chat.get((int)0).get("push key").toString()).commit();
					}
				}
				@Override
				public void onCancelled(DatabaseError _databaseError) {
				}
			});
		}
		else {
			
		}
		if (list_chat_) {
			
		}
	}
	
	
	public void _push_data_online() {
		t2 = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (last_seen_) {
							t2.cancel();
						}
						else {
							c = Calendar.getInstance();
							map_last_seen.put("jam", new SimpleDateFormat("HH.mm").format(c.getTime()));
							map_last_seen.put("tanggal", new SimpleDateFormat("dd/MM/yyyy").format(c.getTime()));
							map_last_seen.put("millisecond", String.valueOf((long)(c.getTimeInMillis())));
							map_last_seen.put("gmt", new SimpleDateFormat("ZZZZ").format(c.getTime()));
							data_user.child("ims last seen").updateChildren(map_last_seen);
						}
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(t2, (int)(0), (int)(400));
	}
	
	
	public void _circleRipple(final String _color, final View _v) {
		android.content.res.ColorStateList clrb = new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{Color.parseColor(_color)});
		android.graphics.drawable.RippleDrawable ripdrb = new android.graphics.drawable.RippleDrawable(clrb , null, null);
		_v.setBackground(ripdrb);
	}
	
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		int style = 0;
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					
					if (((TextView) v).getTypeface().getStyle()==Typeface.NORMAL) {
						
						style = 0;
						
					}else{
						
						if (((TextView) v).getTypeface().getStyle()==Typeface.BOLD) {
							
							style = 1;
							
						}else{
							
							if (((TextView) v).getTypeface().getStyle()==Typeface.ITALIC) {
								
								style = 2;
								
							}else{
								
								if (((TextView) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
									
									style = 3;
									
								}}}}
					
					((TextView) v).setTypeface(typeace, (style));
					
				}
				else {
					if ((v instanceof EditText )) {
						if (((EditText) v).getTypeface().getStyle()==Typeface.NORMAL) {
							
							style = 0;
							
						}else{
							
							if (((EditText) v).getTypeface().getStyle()==Typeface.BOLD) {
								
								style = 1;
								
							}else{
								
								if (((EditText) v).getTypeface().getStyle()==Typeface.ITALIC) {
									
									style = 2;
									
								}else{
									
									if (((EditText) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
										
										style = 3;
										
									}}}}
						
						((EditText) v).setTypeface(typeace, (style));
					}
					else {
						if ((v instanceof RadioButton )) {
							if (((RadioButton) v).getTypeface().getStyle()==Typeface.NORMAL) {
								
								style = 0;
								
							}else{
								
								if (((RadioButton) v).getTypeface().getStyle()==Typeface.BOLD) {
									
									style = 1;
									
								}else{
									
									if (((RadioButton) v).getTypeface().getStyle()==Typeface.ITALIC) {
										
										style = 2;
										
									}else{
										
										if (((RadioButton) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
											
											style = 3;
											
										}}}}
							
							((RadioButton) v).setTypeface(typeace, (style));
						}
						else {
							if ((v instanceof CheckBox )) {
								if (((CheckBox) v).getTypeface().getStyle()==Typeface.NORMAL) {
									
									style = 0;
									
								}else{
									
									if (((CheckBox) v).getTypeface().getStyle()==Typeface.BOLD) {
										
										style = 1;
										
									}else{
										
										if (((CheckBox) v).getTypeface().getStyle()==Typeface.ITALIC) {
											
											style = 2;
											
										}else{
											
											if (((CheckBox) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
												
												style = 3;
												
											}}}}
								
								((CheckBox) v).setTypeface(typeace, (style));
							}
							else {
								if ((v instanceof Switch )) {
									if (((Switch) v).getTypeface().getStyle()==Typeface.NORMAL) {
										
										style = 0;
										
									}else{
										
										if (((Switch) v).getTypeface().getStyle()==Typeface.BOLD) {
											
											style = 1;
											
										}else{
											
											if (((Switch) v).getTypeface().getStyle()==Typeface.ITALIC) {
												
												style = 2;
												
											}else{
												
												if (((Switch) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
													
													style = 3;
													
												}}}}
									
									((Switch) v).setTypeface(typeace, (style));
								}
								else {
									if ((v instanceof Button)) {
										if (((Button) v).getTypeface().getStyle()==Typeface.NORMAL) {
											
											style = 0;
											
										}else{
											
											if (((Button) v).getTypeface().getStyle()==Typeface.BOLD) {
												
												style = 1;
												
											}else{
												
												if (((Button) v).getTypeface().getStyle()==Typeface.ITALIC) {
													
													style = 2;
													
												}else{
													
													if (((Button) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
														
														style = 3;
														
													}}}}
										
										((Button) v).setTypeface(typeace, (style));
									}
								}
							}
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.list_chat_, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = _view.findViewById(R.id.circleimageview1);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView pesan = _view.findViewById(R.id.pesan);
			final TextView username = _view.findViewById(R.id.username);
			final TextView tanggal = _view.findViewById(R.id.tanggal);
			final TextView email = _view.findViewById(R.id.email);
			final LinearLayout linear_titik = _view.findViewById(R.id.linear_titik);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			
			pesan.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
			username.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
			tanggal.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
			email.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/font.ttf"), 0);
			c = Calendar.getInstance();
			pesan.setText(lm_list_chat.get((int)_position).get("pesan").toString());
			pesan.setEllipsize(android.text.TextUtils.TruncateAt.END);
			username.setText(lm_list_chat.get((int)_position).get("uid2").toString());
			if (lm_list_chat.get((int)_position).containsKey("time stamp")) {
				c = Calendar.getInstance();
				ts.setTimeInMillis((long)(Double.parseDouble(lm_list_chat.get((int)_position).get("time stamp").toString())));
				if (new SimpleDateFormat("MMM dd, yyyy").format(c.getTime()).equals(new SimpleDateFormat("MMM dd, yyyy").format(ts.getTime()))) {
					tanggal.setText(new SimpleDateFormat("HH:mm").format(ts.getTime()));
				}
				else {
					tanggal.setText(new SimpleDateFormat("MMM dd, yyyy").format(ts.getTime()));
				}
			}
			else {
				if (lm_list_chat.get((int)_position).get("tanggal").toString().equals(new SimpleDateFormat("dd/MM/yyyy").format(c.getTime()))) {
					tanggal.setText(lm_list_chat.get((int)_position).get("jam").toString());
				}
				else {
					tanggal.setText(lm_list_chat.get((int)_position).get("tanggal").toString());
				}
			}
			get_user = 0;
			for(int _repeat17 = 0; _repeat17 < (int)(lm_data_user.size()); _repeat17++) {
				if (lm_list_chat.get((int)_position).get("uid2").toString().equals(lm_data_user.get((int)get_user).get("uid").toString())) {
					email.setText(lm_data_user.get((int)get_user).get("email").toString());
					username.setText(lm_data_user.get((int)get_user).get("username").toString());
				}
				get_user++;
			}
			_RoundandShadow(15, 0, "#607d8b", linear_titik);
			pesan.setTypeface(null, Typeface.NORMAL);
			linear_titik.setVisibility(View.GONE);
			if (!share.getString(lm_list_chat.get((int)_position).get("uid2").toString(), "").equals(lm_list_chat.get((int)_position).get("push key").toString())) {
				pesan.setTypeface(pesan.getTypeface(), Typeface.BOLD);
				linear_titik.setVisibility(View.VISIBLE);
			}
			imageview2.setVisibility(View.INVISIBLE);
			if (mute.containsKey(lm_list_chat.get((int)_position).get("uid2").toString())) {
				imageview2.setVisibility(View.VISIBLE);
			}
			Glide.with(getApplicationContext()).load(Uri.parse("https://firebasestorage.googleapis.com/v0/b/kasir-65337.appspot.com/o/data%2F".concat(lm_list_chat.get((int)_position).get("uid2").toString().concat("%2Fpic%2Fpic.png?alt=media")))).into(circleimageview1);
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}