package com.scloud.chat;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.FirebaseApp;
import com.jgabrielfreitas.core.*;
import java.io.*;
import java.text.*;
import java.text.DecimalFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class FileManagerActivity extends AppCompatActivity {
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private String lokasi = "";
	private String path = "";
	private double n = 0;
	private HashMap<String, Object> map_file = new HashMap<>();
	private String b = "";
	private String kb = "";
	private String mb = "";
	private String gb = "";
	private String tb = "";
	private String pb = "";
	private String ukuran = "";
	private String error_path = "";
	private String mime_type = "";
	private String filenya = "";
	private String fontName = "";
	private String typeace = "";
	
	private ArrayList<String> ls = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_data = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_file = new ArrayList<>();
	
	private CardView cardview1;
	private TextView textview1;
	private LinearLayout linear1;
	private GridView gridview1;
	private LinearLayout linear4;
	private ImageView imageview2;
	private EditText edittext1;
	private ImageView imageview1;
	private Button button1;
	
	private SharedPreferences share;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.file_manager);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		cardview1 = findViewById(R.id.cardview1);
		textview1 = findViewById(R.id.textview1);
		linear1 = findViewById(R.id.linear1);
		gridview1 = findViewById(R.id.gridview1);
		linear4 = findViewById(R.id.linear4);
		imageview2 = findViewById(R.id.imageview2);
		edittext1 = findViewById(R.id.edittext1);
		imageview1 = findViewById(R.id.imageview1);
		button1 = findViewById(R.id.button1);
		share = getSharedPreferences("share", Activity.MODE_PRIVATE);
		
		gridview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (FileUtil.isFile(lm_file.get((int)_position).get("file").toString())) {
					_get_mime_type(lm_file.get((int)_position).get("file").toString());
					try{
						if (mime_type.contains("image")) {
							filenya = lm_file.get((int)_position).get("file").toString();
							linear1.setVisibility(View.VISIBLE);
							gridview1.setVisibility(View.GONE);
							textview1.setVisibility(View.GONE);
							Glide.with(getApplicationContext()).load(Uri.parse("file://".concat(lm_file.get((int)_position).get("file").toString()))).into(imageview1);
							path = path.concat("/".concat(Uri.parse(lm_file.get((int)_position).get("file").toString()).getLastPathSegment()));
							_scan_and_refresh();
							cardview1.setVisibility(View.GONE);
						}
						else {
							
						}
					}catch(Exception e){
						 
					}
				}
				else {
					path = path.concat("/".concat(Uri.parse(lm_file.get((int)_position).get("file").toString()).getLastPathSegment()));
					_scan_and_refresh();
				}
				textview1.setText(path);
				setTitle(Uri.parse(path).getLastPathSegment());
				getSupportActionBar().setSubtitle(path);
				edittext1.setText("");
			}
		});
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (_charSeq.length() > 0) {
					lm_file.clear();
					n = 0;
					for(int _repeat18 = 0; _repeat18 < (int)(ls.size()); _repeat18++) {
						try{
							if (Uri.parse(ls.get((int)(n))).getLastPathSegment().length() > 0) {
								if (Uri.parse(ls.get((int)(n))).getLastPathSegment().substring((int)(0), (int)(1)).equals(".")) {
									
								}
								else {
									if (FileUtil.isDirectory(ls.get((int)(n))) || (ls.get((int)(n)).endsWith("gif") || (ls.get((int)(n)).endsWith("png") || ls.get((int)(n)).endsWith("jpg")))) {
										if (ls.get((int)(n)).toLowerCase().contains(_charSeq.toLowerCase())) {
											{
												HashMap<String, Object> _item = new HashMap<>();
												_item.put("file", ls.get((int)(n)));
												lm_file.add(_item);
											}
											
										}
										else {
											
										}
									}
									else {
										
									}
								}
							}
							else {
								
							}
						}catch(Exception e){
							error_path = ls.get((int)(n));
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("file", path);
								lm_file.add(_item);
							}
							
							
						}
						n++;
					}
					try{
						SketchwareUtil.sortListMap(lm_file, "file", false, true);
						gridview1.setAdapter(new Gridview1Adapter(lm_file));
						gridview1.setNumColumns((int)3);
						gridview1.setColumnWidth((int)SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 3);
						gridview1.setVerticalSpacing((int)5);
						gridview1.setHorizontalSpacing((int)5);
						gridview1.setStretchMode(GridView.STRETCH_SPACING);
					}catch(Exception e){
						SketchwareUtil.showMessage(getApplicationContext(), "end");
					}
				}
				else {
					_scan_and_refresh();
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				share.edit().putString("sticker path", filenya).commit();
				finish();
			}
		});
	}
	
	private void initializeLogic() {
		_changeActivityFont("font");
		path = FileUtil.getPackageDataDir(getApplicationContext());
		_scan_and_refresh();
		linear1.setVisibility(View.GONE);
		textview1.setText(path);
		button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFF607D8B));
		setTitle(Uri.parse(path).getLastPathSegment());
		getSupportActionBar().setSubtitle(path);
		textview1.setVisibility(View.GONE);
	}
	
	@Override
	public void onBackPressed() {
		if (Uri.parse(path).getLastPathSegment().equals("0")) {
			finish();
		}
		else {
			filenya = "";
			gridview1.setVisibility(View.VISIBLE);
			linear1.setVisibility(View.GONE);
			try{
				path = path.substring((int)(0), (int)(path.lastIndexOf("/")));
				_scan_and_refresh();
			}catch(Exception e){
				finish();
			}
			textview1.setText(path);
			setTitle(Uri.parse(path).getLastPathSegment());
			getSupportActionBar().setSubtitle(path);
			textview1.setVisibility(View.GONE);
			cardview1.setVisibility(View.VISIBLE);
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		
	}
	public void _convert(final String _in, final TextView _out) {
		b = _in;
		kb = String.valueOf((long)(Double.parseDouble(b) / 1024));
		mb = String.valueOf((long)(Double.parseDouble(kb) / 1024));
		gb = String.valueOf((long)(Double.parseDouble(mb) / 1024));
		tb = String.valueOf((long)(Double.parseDouble(gb) / 1024));
		pb = String.valueOf((long)(Double.parseDouble(tb) / 1024));
		if (Double.parseDouble(kb) < 1) {
			ukuran = b.concat(" b");
		}
		else {
			if ((Double.parseDouble(mb) % 1024) < 1) {
				ukuran = String.valueOf((long)(Double.parseDouble(kb) % 1024)).concat(".".concat(new DecimalFormat("00").format((Double.parseDouble(b) % 1024) / 10).concat(" Kb")));
			}
			else {
				if ((Double.parseDouble(gb) % 1024) < 1) {
					ukuran = String.valueOf((long)(Double.parseDouble(mb) % 1024)).concat(".".concat(new DecimalFormat("00").format((Double.parseDouble(kb) % 1024) / 10).concat(" Mb")));
				}
				else {
					if ((Double.parseDouble(tb) % 1024) < 1) {
						ukuran = String.valueOf((long)(Double.parseDouble(gb) % 1024)).concat(".".concat(new DecimalFormat("00").format((Double.parseDouble(mb) % 1024) / 10).concat(" Gb")));
					}
					else {
						if ((Double.parseDouble(pb) % 1024) < 1) {
							ukuran = String.valueOf((long)(Double.parseDouble(tb) % 1024)).concat(".".concat(new DecimalFormat("00").format((Double.parseDouble(gb) % 1024) / 10).concat(" Tb")));
						}
						else {
							ukuran = String.valueOf((long)(Double.parseDouble(pb) % 1024)).concat(".".concat(new DecimalFormat("00").format((Double.parseDouble(tb) % 1024) / 10).concat(" Pb")));
						}
					}
				}
			}
		}
	}
	
	
	public void _scan_and_refresh() {
		ls.clear();
		lm_file.clear();
		try{
			FileUtil.listDir(path, ls);
		}catch(Exception e){
			SketchwareUtil.showMessage(getApplicationContext(), "disini um");
		}
		n = 0;
		for(int _repeat13 = 0; _repeat13 < (int)(ls.size()); _repeat13++) {
			try{
				if (Uri.parse(ls.get((int)(n))).getLastPathSegment().length() > 0) {
					if (Uri.parse(ls.get((int)(n))).getLastPathSegment().substring((int)(0), (int)(1)).equals(".")) {
						
					}
					else {
						if (FileUtil.isDirectory(ls.get((int)(n))) || (ls.get((int)(n)).endsWith("gif") || (ls.get((int)(n)).endsWith("png") || ls.get((int)(n)).endsWith("jpg")))) {
							{
								HashMap<String, Object> _item = new HashMap<>();
								_item.put("file", ls.get((int)(n)));
								lm_file.add(_item);
							}
							
						}
						else {
							
						}
					}
				}
				else {
					
				}
			}catch(Exception e){
				error_path = ls.get((int)(n));
				{
					HashMap<String, Object> _item = new HashMap<>();
					_item.put("file", path);
					lm_file.add(_item);
				}
				
				
			}
			n++;
		}
		try{
			SketchwareUtil.sortListMap(lm_file, "file", false, true);
			gridview1.setAdapter(new Gridview1Adapter(lm_file));
			gridview1.setNumColumns((int)3);
			gridview1.setColumnWidth((int)SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 3);
			gridview1.setVerticalSpacing((int)5);
			gridview1.setHorizontalSpacing((int)5);
			gridview1.setStretchMode(GridView.STRETCH_SPACING);
		}catch(Exception e){
			SketchwareUtil.showMessage(getApplicationContext(), "end");
		}
	}
	
	
	public void _test() {
		
	}
	
	
	public void _get_mime_type(final String _path) {
		
		mime_type = "";
		try{
			mime_type = null;
			String extension = MimeTypeMap.getFileExtensionFromUrl(_path);
			if (extension != null) {
				try{
					
					    
					    
					        mime_type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
				}catch(Exception e){
					SketchwareUtil.showMessage(getApplicationContext(), "error mine type");
				}
			}
			/*<<<<<<
Moreblock by Amitoj
Source: https://stackoverflow.com/a/8591230
>>>>>>*/
		}catch(Exception e){
			 
		}
	}
	
	
	public void _setHeight(final View _view, final double _heightValue, final double _widthValue) {
		_view.getLayoutParams().height = (int)_heightValue;
		_view.requestLayout();
		_view.getLayoutParams().width = (int)_widthValue;
		_view.requestLayout();
	}
	
	
	public void _addCardView(final View _layoutView, final double _margins, final double _cornerRadius, final double _cardElevation, final double _cardMaxElevation, final boolean _preventCornerOverlap, final String _backgroundColor) {
		androidx.cardview.widget.CardView cv = new androidx.cardview.widget.CardView(this);
		LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(200,200);
		int m = (int)_margins;
		lp.setMargins(m,m,m,m);
		cv.setLayoutParams(lp);
		int c = Color.parseColor(_backgroundColor);
		cv.setCardBackgroundColor(c);
		cv.setRadius((float)_cornerRadius);
		cv.setCardElevation((float)_cardElevation);
		cv.setMaxCardElevation((float)_cardMaxElevation);
		cv.setPreventCornerOverlap(_preventCornerOverlap);
		if(_layoutView.getParent() instanceof LinearLayout){
			ViewGroup vg = ((ViewGroup)_layoutView.getParent());
			vg.removeView(_layoutView);
			vg.removeAllViews();
			vg.addView(cv);
			cv.addView(_layoutView);
		}else{
			
		}
	}
	
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		int style = 0;
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					
					if (((TextView) v).getTypeface().getStyle()==Typeface.NORMAL) {
						
						style = 0;
						
					}else{
						
						if (((TextView) v).getTypeface().getStyle()==Typeface.BOLD) {
							
							style = 1;
							
						}else{
							
							if (((TextView) v).getTypeface().getStyle()==Typeface.ITALIC) {
								
								style = 2;
								
							}else{
								
								if (((TextView) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
									
									style = 3;
									
								}}}}
					
					((TextView) v).setTypeface(typeace, (style));
					
				}
				else {
					if ((v instanceof EditText )) {
						if (((EditText) v).getTypeface().getStyle()==Typeface.NORMAL) {
							
							style = 0;
							
						}else{
							
							if (((EditText) v).getTypeface().getStyle()==Typeface.BOLD) {
								
								style = 1;
								
							}else{
								
								if (((EditText) v).getTypeface().getStyle()==Typeface.ITALIC) {
									
									style = 2;
									
								}else{
									
									if (((EditText) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
										
										style = 3;
										
									}}}}
						
						((EditText) v).setTypeface(typeace, (style));
					}
					else {
						if ((v instanceof RadioButton )) {
							if (((RadioButton) v).getTypeface().getStyle()==Typeface.NORMAL) {
								
								style = 0;
								
							}else{
								
								if (((RadioButton) v).getTypeface().getStyle()==Typeface.BOLD) {
									
									style = 1;
									
								}else{
									
									if (((RadioButton) v).getTypeface().getStyle()==Typeface.ITALIC) {
										
										style = 2;
										
									}else{
										
										if (((RadioButton) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
											
											style = 3;
											
										}}}}
							
							((RadioButton) v).setTypeface(typeace, (style));
						}
						else {
							if ((v instanceof CheckBox )) {
								if (((CheckBox) v).getTypeface().getStyle()==Typeface.NORMAL) {
									
									style = 0;
									
								}else{
									
									if (((CheckBox) v).getTypeface().getStyle()==Typeface.BOLD) {
										
										style = 1;
										
									}else{
										
										if (((CheckBox) v).getTypeface().getStyle()==Typeface.ITALIC) {
											
											style = 2;
											
										}else{
											
											if (((CheckBox) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
												
												style = 3;
												
											}}}}
								
								((CheckBox) v).setTypeface(typeace, (style));
							}
							else {
								if ((v instanceof Switch )) {
									if (((Switch) v).getTypeface().getStyle()==Typeface.NORMAL) {
										
										style = 0;
										
									}else{
										
										if (((Switch) v).getTypeface().getStyle()==Typeface.BOLD) {
											
											style = 1;
											
										}else{
											
											if (((Switch) v).getTypeface().getStyle()==Typeface.ITALIC) {
												
												style = 2;
												
											}else{
												
												if (((Switch) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
													
													style = 3;
													
												}}}}
									
									((Switch) v).setTypeface(typeace, (style));
								}
								else {
									if ((v instanceof Button)) {
										if (((Button) v).getTypeface().getStyle()==Typeface.NORMAL) {
											
											style = 0;
											
										}else{
											
											if (((Button) v).getTypeface().getStyle()==Typeface.BOLD) {
												
												style = 1;
												
											}else{
												
												if (((Button) v).getTypeface().getStyle()==Typeface.ITALIC) {
													
													style = 2;
													
												}else{
													
													if (((Button) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
														
														style = 3;
														
													}}}}
										
										((Button) v).setTypeface(typeace, (style));
									}
								}
							}
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	public class Gridview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.file_m, null);
			}
			
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			textview1.setText(Uri.parse(lm_file.get((int)_position).get("file").toString()).getLastPathSegment());
			_setHeight(linear1, (SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 3) - 5, (SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 3) - 5);
			_setHeight(imageview1, (SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 3) - 90, (SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 3) - 90);
			_setHeight(textview2, (SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 3) - 90, (SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 3) - 90);
			if (FileUtil.isFile(lm_file.get((int)_position).get("file").toString())) {
				textview2.setVisibility(View.GONE);
				imageview1.setVisibility(View.VISIBLE);
				imageview1.setImageResource(R.drawable.ic_description_grey);
				try{
					_get_mime_type(lm_file.get((int)_position).get("file").toString());
					if (mime_type.contains("image")) {
						Glide.with(getApplicationContext()).load(Uri.parse("file://".concat(lm_file.get((int)_position).get("file").toString()))).into(imageview1);
						textview2.setVisibility(View.GONE);
						imageview1.setVisibility(View.VISIBLE);
					}
					else {
						textview2.setVisibility(View.VISIBLE);
						imageview1.setVisibility(View.GONE);
						textview2.setText(lm_file.get((int)_position).get("file").toString().substring((int)(lm_file.get((int)_position).get("file").toString().lastIndexOf(".")), (int)(lm_file.get((int)_position).get("file").toString().length())));
					}
				}catch(Exception e){
					 
				}
			}
			else {
				textview2.setVisibility(View.GONE);
				imageview1.setVisibility(View.VISIBLE);
				imageview1.setImageResource(R.drawable.folderr);
			}
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}