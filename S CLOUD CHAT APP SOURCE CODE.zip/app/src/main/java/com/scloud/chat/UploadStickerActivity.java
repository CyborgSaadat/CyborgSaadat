package com.scloud.chat;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.jgabrielfreitas.core.*;
import java.io.*;
import java.io.File;
import java.text.*;
import java.text.DecimalFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class UploadStickerActivity extends AppCompatActivity {
	
	public final int REQ_CD_FP = 101;
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private String sticker_patch = "";
	private String stiker_str = "";
	private String key = "";
	private HashMap<String, Object> map = new HashMap<>();
	private HashMap<String, Object> downloaded_sticker = new HashMap<>();
	private String error = "";
	private double size = 0;
	private String sizeOfFile = "";
	private String lokasi_asli_file = "";
	private HashMap<String, Object> key_sticker = new HashMap<>();
	private String stiker_key_str = "";
	private String fontName = "";
	private String typeace = "";
	
	private ArrayList<String> ls = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm_stiker = new ArrayList<>();
	
	private LinearLayout linear1;
	private ImageView imageview1;
	private Button button1;
	
	private Intent fp = new Intent(Intent.ACTION_GET_CONTENT);
	private StorageReference stiker_fs = _firebase_storage.getReference("stiker");
	private OnCompleteListener<Uri> _stiker_fs_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _stiker_fs_download_success_listener;
	private OnSuccessListener _stiker_fs_delete_success_listener;
	private OnProgressListener _stiker_fs_upload_progress_listener;
	private OnProgressListener _stiker_fs_download_progress_listener;
	private OnFailureListener _stiker_fs_failure_listener;
	
	private DatabaseReference stiker_db = _firebase.getReference(""+stiker_str+"");
	private ChildEventListener _stiker_db_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private SharedPreferences share;
	private DatabaseReference test = _firebase.getReference("test");
	private ChildEventListener _test_child_listener;
	private StorageReference data_ = _firebase_storage.getReference("data");
	private OnCompleteListener<Uri> _data__upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _data__download_success_listener;
	private OnSuccessListener _data__delete_success_listener;
	private OnProgressListener _data__upload_progress_listener;
	private OnProgressListener _data__download_progress_listener;
	private OnFailureListener _data__failure_listener;
	
	private DatabaseReference stiker_key = _firebase.getReference(""+stiker_key_str+"");
	private ChildEventListener _stiker_key_child_listener;
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.upload_sticker);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = findViewById(R.id.linear1);
		imageview1 = findViewById(R.id.imageview1);
		button1 = findViewById(R.id.button1);
		fp.setType("*/*");
		fp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		auth = FirebaseAuth.getInstance();
		share = getSharedPreferences("share", Activity.MODE_PRIVATE);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), FileManagerActivity.class);
				startActivity(i);
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (sticker_patch.equals("")) {
					
				}
				else {
					_showProgressDialog(true, "Uploading", "Uploading your sticker...");
					FileUtil.copyFile(lokasi_asli_file, sticker_patch);
					stiker_db.removeEventListener(_stiker_db_child_listener);
					stiker_str = "stiker/".concat(key);
					stiker_db = _firebase.getReference(stiker_str);
					stiker_db.addChildEventListener(_stiker_db_child_listener);
					stiker_key.removeEventListener(_stiker_key_child_listener);
					stiker_key_str = "stiker key/".concat("");
					stiker_key = _firebase.getReference(stiker_key_str);
					stiker_key.addChildEventListener(_stiker_key_child_listener);
					try {
						stiker_fs.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("/".concat(key))).putFile(Uri.fromFile(new File(sticker_patch))).addOnFailureListener(_stiker_fs_failure_listener).addOnProgressListener(_stiker_fs_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
							@Override
							public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
								return stiker_fs.child(FirebaseAuth.getInstance().getCurrentUser().getUid().concat("/".concat(key))).getDownloadUrl();
							}}).addOnCompleteListener(_stiker_fs_upload_success_listener);
					}
					catch (Exception e)
					{
						error = e.toString();
						SketchwareUtil.showMessage(getApplicationContext(), error);
					}
				}
			}
		});
		
		_stiker_fs_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				_showProgressDialog(true, "Uploading", "Uploading sticker ".concat(String.valueOf((long)(_progressValue)).concat("...")));
			}
		};
		
		_stiker_fs_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_stiker_fs_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				map.clear();
				map.put(key, "true");
				stiker_key.child("data").updateChildren(map);
				map.put("stiker", _downloadUrl);
				map.put("id stiker", key);
				map.put("ukuran", sizeOfFile);
				map.put("ekspresi", "");
				stiker_db.child("data").updateChildren(map);
				FileUtil.moveFile(sticker_patch, FileUtil.getPackageDataDir(getApplicationContext()).concat("/stiker/".concat(key)));
				lokasi_asli_file = "";
				sticker_patch = "";
				downloaded_sticker.put("stiker", FileUtil.getPackageDataDir(getApplicationContext()).concat("/stiker/".concat(key)));
				downloaded_sticker.put("id stiker", key);
				downloaded_sticker.put("ukuran stiker", sizeOfFile);
				lm_stiker.add(downloaded_sticker);
				share.edit().putString("stiker", new Gson().toJson(lm_stiker)).commit();
				key_sticker.put(key, "true");
				share.edit().putString("key sticker", new Gson().toJson(key_sticker)).commit();
				_showProgressDialog(false, "", "");
				finish();
			}
		};
		
		_stiker_fs_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_stiker_fs_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_stiker_fs_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				_showProgressDialog(false, "", "");
				SketchwareUtil.showMessage(getApplicationContext(), _message);
			}
		};
		
		_stiker_db_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		stiker_db.addChildEventListener(_stiker_db_child_listener);
		
		_test_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		test.addChildEventListener(_test_child_listener);
		
		_data__upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_data__download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_data__upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				
			}
		};
		
		_data__download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_data__delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_data__failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_stiker_key_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		stiker_key.addChildEventListener(_stiker_key_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		_changeActivityFont("font");
		if (!share.getString("key sticker", "").equals("")) {
			key_sticker = new Gson().fromJson(share.getString("key sticker", ""), new TypeToken<HashMap<String, Object>>(){}.getType());
		}
		if (!share.getString("stiker", "").equals("")) {
			lm_stiker.clear();
			lm_stiker = new Gson().fromJson(share.getString("stiker", ""), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		}
		button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)50, 0xFF607D8B));
		setTitle("Sticker upload");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FP:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				key = test.push().getKey();
				if (!FileUtil.isExistFile(FileUtil.getPackageDataDir(getApplicationContext()).concat("/upload_temp_s/"))) {
					FileUtil.makeDir(FileUtil.getPackageDataDir(getApplicationContext()).concat("/upload_temp_s/"));
				}
				_getSizeOfFile(_filePath.get((int)(0)));
				if (Double.parseDouble(sizeOfFile.substring((int)(0), (int)(sizeOfFile.indexOf(",")))) < 500) {
					lokasi_asli_file = _filePath.get((int)(0));
					Glide.with(getApplicationContext()).load(Uri.parse("file://".concat(_filePath.get((int)(0))))).into(imageview1);
					sticker_patch = FileUtil.getPackageDataDir(getApplicationContext()).concat("/upload_temp_s/").concat(key);
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Sticker size max is 500KB");
					sticker_patch = "";
					lokasi_asli_file = "";
				}
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		if (share.getString("sticker path", "").equals("")) {
			
		}
		else {
			key = test.push().getKey();
			if (!FileUtil.isExistFile(FileUtil.getPackageDataDir(getApplicationContext()).concat("/upload_temp_s/"))) {
				FileUtil.makeDir(FileUtil.getPackageDataDir(getApplicationContext()).concat("/upload_temp_s/"));
			}
			_getSizeOfFile(share.getString("sticker path", ""));
			if (Double.parseDouble(sizeOfFile.substring((int)(0), (int)(sizeOfFile.indexOf(",")))) < 1024) {
				lokasi_asli_file = share.getString("sticker path", "");
				Glide.with(getApplicationContext()).load(Uri.parse("file://".concat(share.getString("sticker path", "")))).into(imageview1);
				sticker_patch = FileUtil.getPackageDataDir(getApplicationContext()).concat("/upload_temp_s/").concat(key);
			}
			else {
				SketchwareUtil.showMessage(getApplicationContext(), "Sticker size max is 1MB");
				sticker_patch = "";
				lokasi_asli_file = "";
			}
		}
		share.edit().putString("sticker path", "").commit();
	}
	public void _getSizeOfFile(final String _path) {
		// This MoreBlock by Yassine Bada
		size = FileUtil.getFileLength(_path) * 0.001d;
		sizeOfFile = new DecimalFormat("###0.##").format(size).concat(" KB");
		// Use this variable : SizeOfFile after putting this MoreBlock to get the size of a file by indicate the file's path
	}
	
	
	public void _showProgressDialog(final boolean _ifShow, final String _title, final String _message) {
		if (_ifShow) {
			if (prog == null){
				prog = new ProgressDialog(this);
				prog.setMax(100);
				prog.setIndeterminate(true);
				prog.setCancelable(false);
				prog.setCanceledOnTouchOutside(false);
			}
			prog.setTitle(_title);
			prog.setMessage(_message);
			prog.show();
		}
		else {
			if (prog != null){
				prog.dismiss();
			}
		}
	}
	private ProgressDialog prog;
	{
	}
	
	
	public void _changeActivityFont(final String _fontname) {
		fontName = "fonts/".concat(_fontname.concat(".ttf"));
		overrideFonts(this,getWindow().getDecorView()); 
	} 
	private void overrideFonts(final android.content.Context context, final View v) {
		
		int style = 0;
		
		try {
			Typeface 
			typeace = Typeface.createFromAsset(getAssets(), fontName);;
			if ((v instanceof ViewGroup)) {
				ViewGroup vg = (ViewGroup) v;
				for (int i = 0;
				i < vg.getChildCount();
				i++) {
					View child = vg.getChildAt(i);
					overrideFonts(context, child);
				}
			}
			else {
				if ((v instanceof TextView)) {
					
					if (((TextView) v).getTypeface().getStyle()==Typeface.NORMAL) {
						
						style = 0;
						
					}else{
						
						if (((TextView) v).getTypeface().getStyle()==Typeface.BOLD) {
							
							style = 1;
							
						}else{
							
							if (((TextView) v).getTypeface().getStyle()==Typeface.ITALIC) {
								
								style = 2;
								
							}else{
								
								if (((TextView) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
									
									style = 3;
									
								}}}}
					
					((TextView) v).setTypeface(typeace, (style));
					
				}
				else {
					if ((v instanceof EditText )) {
						if (((EditText) v).getTypeface().getStyle()==Typeface.NORMAL) {
							
							style = 0;
							
						}else{
							
							if (((EditText) v).getTypeface().getStyle()==Typeface.BOLD) {
								
								style = 1;
								
							}else{
								
								if (((EditText) v).getTypeface().getStyle()==Typeface.ITALIC) {
									
									style = 2;
									
								}else{
									
									if (((EditText) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
										
										style = 3;
										
									}}}}
						
						((EditText) v).setTypeface(typeace, (style));
					}
					else {
						if ((v instanceof RadioButton )) {
							if (((RadioButton) v).getTypeface().getStyle()==Typeface.NORMAL) {
								
								style = 0;
								
							}else{
								
								if (((RadioButton) v).getTypeface().getStyle()==Typeface.BOLD) {
									
									style = 1;
									
								}else{
									
									if (((RadioButton) v).getTypeface().getStyle()==Typeface.ITALIC) {
										
										style = 2;
										
									}else{
										
										if (((RadioButton) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
											
											style = 3;
											
										}}}}
							
							((RadioButton) v).setTypeface(typeace, (style));
						}
						else {
							if ((v instanceof CheckBox )) {
								if (((CheckBox) v).getTypeface().getStyle()==Typeface.NORMAL) {
									
									style = 0;
									
								}else{
									
									if (((CheckBox) v).getTypeface().getStyle()==Typeface.BOLD) {
										
										style = 1;
										
									}else{
										
										if (((CheckBox) v).getTypeface().getStyle()==Typeface.ITALIC) {
											
											style = 2;
											
										}else{
											
											if (((CheckBox) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
												
												style = 3;
												
											}}}}
								
								((CheckBox) v).setTypeface(typeace, (style));
							}
							else {
								if ((v instanceof Switch )) {
									if (((Switch) v).getTypeface().getStyle()==Typeface.NORMAL) {
										
										style = 0;
										
									}else{
										
										if (((Switch) v).getTypeface().getStyle()==Typeface.BOLD) {
											
											style = 1;
											
										}else{
											
											if (((Switch) v).getTypeface().getStyle()==Typeface.ITALIC) {
												
												style = 2;
												
											}else{
												
												if (((Switch) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
													
													style = 3;
													
												}}}}
									
									((Switch) v).setTypeface(typeace, (style));
								}
								else {
									if ((v instanceof Button)) {
										if (((Button) v).getTypeface().getStyle()==Typeface.NORMAL) {
											
											style = 0;
											
										}else{
											
											if (((Button) v).getTypeface().getStyle()==Typeface.BOLD) {
												
												style = 1;
												
											}else{
												
												if (((Button) v).getTypeface().getStyle()==Typeface.ITALIC) {
													
													style = 2;
													
												}else{
													
													if (((Button) v).getTypeface().getStyle()==Typeface.BOLD_ITALIC) {
														
														style = 3;
														
													}}}}
										
										((Button) v).setTypeface(typeace, (style));
									}
								}
							}
						}
					}
				}
			}
		}
		catch(Exception e)
		
		{
			SketchwareUtil.showMessage(getApplicationContext(), "Error Loading Font");
		};
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}